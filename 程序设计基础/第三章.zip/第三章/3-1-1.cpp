//year and month
#include <iostream>
using namespace std;

int main() {
	int iYear, iMonth, iDays;
	cout << "please input year:";
	cin >> iYear;
	cout << "please input month:";
	cin >> iMonth;
	bool isLeap = 0;
	if ((iYear % 4 == 0 && iYear % 100 != 0) || (iYear % 400 == 0))
		isLeap = 1;
	switch (iMonth) {
		case 2:
			if (isLeap)
				iDays = 29;
			else
				iDays = 28;
			break;
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			iDays = 31;
			break;
		default:
			iDays = 30;
	}
	cout << "There are " << iDays << " days";
	return 0;
}
