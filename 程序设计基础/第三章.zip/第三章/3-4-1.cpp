#include <iostream>
using namespace std;

int main() {
	int n, sum = 0;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		//����n�Ľ׳�
		int mul = 1;
		for (int j = 1; j <= i; j++)
			mul = mul * j;
		sum = sum + mul;
	}
	cout << "1!+....+" << n << "!=" << sum;
	return 0;
}
