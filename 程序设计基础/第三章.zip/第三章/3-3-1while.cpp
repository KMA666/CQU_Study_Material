#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	string s;
	cin >> s;
	int isum = 0;
	int i = s.length() - 1;
	while (i >= 0) {

		cout << setw(3) << s[i];
		isum = isum + (s[i] - '0');
		i--;
	}
	cout << endl;
	cout << "sum is " << isum;

	return 0;
}
