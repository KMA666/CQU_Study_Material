#include <iostream>
using namespace std;

int main() {
	string s = "";
	while (s != "q") {
		getline(cin, s);
		cout << s << endl;
	}

	return 0;
}
