#include <iostream>
using namespace std;

int main() {
	int f0 = 1, f1 = 1, fn;
	int n;
	cin >> n;
	cout << f0 << "," << f1;
	for (int i = 2; i <= n; i++) {
		fn = f0 + f1;
		f0 = f1;
		f1 = fn;
		cout << "," << fn;
	}
	return 0;
}
