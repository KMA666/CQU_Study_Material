#include <iostream>
using namespace std;

int main() {
	int chickhead, rabbithead;
	for ( chickhead = 1; chickhead < 35; chickhead++) {
		rabbithead = 35 - chickhead;
		if (chickhead * 2 + rabbithead * 4 == 94)
			break;
	}
	cout << "the number of chick is " << chickhead
	     << " and the number of rabbit is " << rabbithead;
	return 0;
}
