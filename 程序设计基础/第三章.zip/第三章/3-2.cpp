#include <iostream>
using namespace std;

int main() {
	int isum = 0;
	for (int i = 0; i < 3; i++) {
		cout << "loop i=" << i << endl;
		isum = isum + i;
	}
	cout << "sum = " << isum;
	return 0;
}
