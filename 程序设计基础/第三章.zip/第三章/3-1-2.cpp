//next date
#include <iostream>
using namespace std;

int main() {
	int iYear, iMonth, iNumber, iDays;
	cout << "please input year,month,day:";
	cin >> iYear >> iMonth >> iNumber;

	bool isLeap = 0;
	if ((iYear % 4 == 0 && iYear % 100 != 0) || (iYear % 400 == 0))
		isLeap = 1;
	switch (iMonth) {
		case 2:
			if (isLeap)
				iDays = 29;
			else
				iDays = 28;
			break;
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			iDays = 31;
			break;
		default:
			iDays = 30;
	}
	iNumber++;
	if (iNumber > iDays) {
		iNumber = 1;
		iMonth++;
		if (iMonth > 12) {
			iYear++;
			iMonth = 1;
		}
	}
	cout << "next day is: " << iYear << "-" << iMonth << "-" << iNumber << endl;
	return 0;
}
