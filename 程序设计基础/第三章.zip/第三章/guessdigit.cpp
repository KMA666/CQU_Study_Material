//guessdigit
#include <iostream>
using namespace std;

int main() {
	int number = rand() % 100 + 1;
	int iDigit = 0;
	while (iDigit != number) {
		cout << "please input number:";
		cin >> iDigit;
		if (iDigit == 0)
			return 0;
		if (iDigit == number)
			cout << "you win!" << endl;
		else {
			if (iDigit > number)
				cout << "bigger!" << endl;
			else
				cout << "smaller!" << endl;
		}
	}
	return 0;
}
