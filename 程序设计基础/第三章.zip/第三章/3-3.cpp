#include <iostream>
#include<iomanip>
using namespace std;

int main() {
	int i,isum=0;
	cin>>i;
	while(i!=0)
	{
		int d=i%10;
		i=i/10;
		isum=isum+d;
		cout<<setw(5)<<d;
	}
	cout<<"\n sum is :"<<isum;

	return 0;
}
