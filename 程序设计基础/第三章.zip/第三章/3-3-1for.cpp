#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	string s;
	cin >> s;
	int sum = 0;
	for (int i = s.length() - 1; i >= 0; i--) {
		cout << setw(3) << s[i];
		sum = sum + (s[i] - '0');
	}
	cout << endl << "sum is " << sum;
	return 0;
}
