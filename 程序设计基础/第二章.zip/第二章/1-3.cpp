//变量的赋值
#include<iostream>
using namespace std;

int main()
{
	int  myAge=18;		//变量的初始化
	cout<<"myAge="<<myAge<<endl;
	myAge=20;			//变量的赋值
	cout<<"myAge="<< myAge<< endl;
	return  0;
}

