#include <iostream>
#include <iomanip>
using namespace std ;


int main () {
	char  name [21] ;
	cout << "What is your name? " ;
	cin >> name ;
	cout << "Hi, " << name << endl ;

//	///////////////////////////////////////
//	string sname;
//	cout << "What is your name? " ;
//	cin >> sname ;
//	cout << "Hello�? << sname << endl ;
	return 0;
}
