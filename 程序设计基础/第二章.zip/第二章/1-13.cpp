#include<iostream>
using namespace std;
int main()
{
	int head=35,feet=94;
	int rabbit=(feet-head*2)/2;
	int chick=head-rabbit;
	cout<<"兔子数目为："<<rabbit<<endl;
	cout<<"鸡的数目为："<<chick<<endl;
	return 0;
}
