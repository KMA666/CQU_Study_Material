#include <iostream>
using namespace std;
enum weekday {sun,mon,tue,wed,thu,fri,sat};
int main()
{	cout<<"今天是星期（请输入一个数0-6编号）：";
	int n;
	cin>>n;
	weekday today = (weekday)n;
	weekday thatday = (weekday)((today+10)%7);
	cout<<"十天后星期（0-6编号）"<<thatday<<endl;
    return 0;
}
