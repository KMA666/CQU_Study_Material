#include <iostream>

using namespace std ;

int main () {
	int a;
	cout << "digit? ";
	cin >> a;
	//cout << "digit: " << a << endl ;
//	cin.ignore();
	string  sentence;
	cout << "string:" ;
	getline( cin, sentence );
	cout << "string is:" << sentence << endl ;
	return 0;
}
