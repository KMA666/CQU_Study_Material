#include <iostream>
#include<bitset>
using namespace std ;
int main (){
  unsigned short value=0101675;
  cout<<value<<":"<<bitset<sizeof(value)*8>(value)<<endl;
  int start=5,end=8;
  unsigned short result=value<<start-1;
  result>>=16-(end-start+1);
  cout<<result<<":"<<bitset<sizeof(result)*8>(result)<<endl;
	return 0;
}
