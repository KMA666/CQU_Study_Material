#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	int d;
	cin >> d;
	cout << (d + 1) % 7;

	return 0;
}
