#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	char c = 'A';
	cout << c + 32 << endl;

	char d = '6';
	cout << "�ַ�6��ASCII��ֵ��" << int(d) << endl;
	cout << d - '0' << endl;

	return 0;
}
