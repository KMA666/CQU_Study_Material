#include <iostream>
#include<iomanip>
using namespace std ;


int main (){
    char word[81];
	cin.getline(word,81);
	cout<<"输入的第一句："<<word<<endl;
	
///////////////////////////////////////
	string sword;
	getline(cin,sword);
	cout<<"输入的第二句："<<sword<<endl;
	return 0;
}
