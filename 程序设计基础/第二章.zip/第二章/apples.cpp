#include <cstdio>
using namespace std;

int main() {
	int n ;
	float fPrice ;
	scanf("%d,%f", &n, &fPrice);
	float fAmount = n * fPrice;
	float fMoney = 20;
	fMoney = fMoney - fAmount;
	printf("%d apples,%.1f for each,%.2f in total.\n", n, fPrice, fMoney);

	return 0;
}