#include<iostream>
using namespace std;
int main()
{
	int a, b; 		   // 定义2个变量
	cout << "输入变量a和b：" ;
	/* 从键盘输入a和b的值 */
	cin >> a >> b;	
	cout << "a + b = " << a + b << endl;	

	return 0;
}
