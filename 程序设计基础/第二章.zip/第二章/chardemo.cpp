#include <iostream>
using namespace std;

int main() {
	int a = 97;
	char c = 'a';
	cout << a << " " << c << endl;
	return 0;
}
