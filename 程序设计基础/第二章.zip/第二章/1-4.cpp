
#include<iostream>
using namespace std;

int main()
{
	int a = 3;
	a = a + 2;
	cout << "a = " << a << endl;
	
	int b = 3;
	b += 2;       //复合运算符，等价于b = b + 2
	cout << "b = " << b << endl;

	return  0;
}

