#include <iostream>

using namespace std ;
int main (){
	int       whole ;
	float    fractional ;
	char    letter ;	
	cout << "请输入一个整数、浮点数和字符：" ;
	cin >> whole >> fractional >> letter ;
    cout<<whole<<" "<<fractional<<" "<<letter<<endl;
	return 0;
}
