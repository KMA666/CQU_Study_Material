#include<iostream>
using namespace std;
int main()
{
	cout<<'\x61'<<' '<<'\141'<<' '<<'a'<<endl;
	return 0;
}
