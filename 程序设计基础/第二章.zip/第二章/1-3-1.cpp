#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	int num = 234, a, b, c;

	a = num % 10;
	num = num / 10;
	b = num % 10;
	num = num / 10;
	c = num % 10;
	cout << setw(2) << a << setw(2) << b << setw(2) << c;

	return 0;
}
