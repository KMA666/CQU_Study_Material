#include <iostream>
#include<iomanip>
using namespace std ;
int main (){
	float a,b;
	cout << "请依次输入两个数：" ;
	cin>>a>>b;
	cout<<setw(10)<<a<<endl;
	cout<<setw(10)<<b<<endl;
	
	return 0;
}
