#include <iostream>
#include<iomanip>
using namespace std ;
int main (){
	char word[8];
	cin>>setw(5)>>word;
	cout<<"输入的单词是："<<word;
	
	return 0;
}
