#include<iostream>
using namespace std;
int main()
{
	short int a=7;
	short int b=a<<1;
	cout<<b<<endl;
	
	
	a=-2;
	b=a>>2;
	cout<<b<<endl;
	return 0;
}
