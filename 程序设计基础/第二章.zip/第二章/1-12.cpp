#include<iostream>
using namespace std;
int main()
{
	enum weekday {Sun, Mon, Tue, Wed, Thu, Fri, Sat } ;
	weekday day1,day2;
	day1=Sat;
	cout<<day1<<endl;
	day2=weekday(0);
	cout<<day2<<endl;
	return 0;
}
