#include <iostream>
#include <iomanip>
using namespace std;

void swap(int x, int y);

int main ( )
{    
    int  x=10, y=20;    

    swap(x, y);
    cout<< setw(6) << x << setw(6) << y << endl ;

    system("pause"); 
    return 0; 
}

void swap(int x, int y)
{    
    int t; 		// ������ִ�д���ʱ��t��ֵ��ȷ����
    
    t=x;    
    x=y;    
    y=t;
    cout<< setw(6) << x << setw(6) <<y << endl ;
}