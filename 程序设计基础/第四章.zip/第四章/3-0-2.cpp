//Project - 求质数
#include <iostream>
#include<iomanip>
#include<cmath>
using namespace std;
bool judge(int num)
{
	for(int i=2;i<=(int)sqrt(num);i++)
	{
		if (num%i==0)
		{
			return false;			
		}
	}
	return true;
}
int main(){
	
	for(int num=100;num<=150;num++)
	{
		bool flag;
		//判断是否为质数
	    flag=judge(num);
		if(flag)
			cout<<setw(8)<<num<<endl;
		
	}
	return 0;
}
