// Ex3-a.cpp
#include <iostream>
#include"ex3-b.cpp"
using namespace std;
int   x=3, y=5;
extern int add( );   
int main ( )
{	
	cout << add( ) << endl;

	return 0; 
} 
