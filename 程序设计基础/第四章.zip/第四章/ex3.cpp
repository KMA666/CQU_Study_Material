#include <iostream>

using namespace std;

int main ( )
{	
	int a=9;
	int b=3;
	{
		int a=10;
		int c=5;
		cout<<"a="<<a<<",&a="<<&a<<endl;
		cout<<"b="<<b<<",&b="<<&b<<endl;
		cout<<"c="<<c<<",&c="<<&c<<endl;
	}
	cout<<"a="<<a<<",&a="<<&a<<endl;
	cout<<"b="<<b<<",&b="<<&b<<endl;
	
	return  0; 
}


