#include <iostream>
#include <iomanip>
using namespace std;
void  fun ( )
{	static int  a;         // 局部静态变量
	int  b = 1;
	
	a++;
	b++;
	cout << a<< setw(6)<<b<<endl;
}
int  main ( )
{
	for( int  i = 0; i < 5; i++)
		fun( );
	return  0; 
}

