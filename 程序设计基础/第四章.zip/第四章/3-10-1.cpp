#include  <iostream>
using namespace std;
int add(int a,int b)
{
	return a+b;
}
double add(double a,double b)
{
	return a+b;
}
string add(string a,string b)
{
	return a+b;
}

int  main ( )
{
	cout<<add(2,3)<<endl;
	cout<<add(1.3,3.4)<<endl;
	cout<<add("hello,","world!")<<endl;
	return 0; 
}


