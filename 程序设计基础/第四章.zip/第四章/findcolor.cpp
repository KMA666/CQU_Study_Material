#include <iostream>
#include <cstring>
using namespace std;
string trans(char c);

int main() {
	char c;
	string s;
	cout<<"input (r-red  y-yellow g-green c-cyan b-blue):"<<endl;
	c = getchar();
	getchar();
	while (!isdigit(c)) {
		s = trans(c);
		cout << s << endl;
		c = getchar();
		getchar();
	}
	return 0;
}

string trans(char c) {
	string s;
	switch (c) {
		case 'r':
			s = "red";
			break;
		case 'y':
			s = "yellow";
			break;
		case 'b':
			s = "blue";
			break;
		case 'c':
			s = "cyan";
			break;
		case 'g':
			s = "green";
			break;
		default:
			s = "no color!";

	}
	return s;
}
