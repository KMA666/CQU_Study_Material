//界面显示示例
#include <iostream>
#include<iomanip>
#include<cmath>
using namespace std;
void displ()
{
	system("cls");
	cout<<"**********************"<<endl;
	cout<<"***1.录入学生成绩*****"<<endl;
	cout<<"***2.查询学生成绩*****"<<endl;
	cout<<"***3.退出        *****"<<endl;
	cout<<"**********************"<<endl;
	cout<<"请输入选项（1-3）：***"<<endl;
}
int main(){
	while(1)
	{
		displ();
		int sel;
		cin>>sel;
		switch(sel)
		{
		case 1:
		    system("cls");
			cout<<"欢迎进入成绩输入界面！"<<endl;
			system("pause");
			break;
		case 2:
			system("cls");
			cout<<"欢迎进入成绩查询...."<<endl;
			system("pause");
			break;
		case 3:
			cout<<"再见...."<<endl;
			exit(1);
			break;
		default:
			cout<<"输入错误请重新输入："<<endl;	
			system("pause");			
		}
			
	}
	
	return 0;
}
