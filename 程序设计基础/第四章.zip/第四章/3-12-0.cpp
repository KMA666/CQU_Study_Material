#include  <iostream>
#include<string>
using namespace std;
template <class T>
T add(T a,T b)
{
	return a+b;
	
}
int main()
{
	cout<<add(2,3)<<endl;
	cout<<add(1.3,3.4)<<endl;
	string s1="hello,";
	string s2="world!";
	cout<<add(s1,s2)<<endl;
	return 0;
}
	
	
	
	
	


