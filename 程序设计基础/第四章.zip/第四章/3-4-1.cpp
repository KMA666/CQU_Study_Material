#include <iostream>
#include <iomanip>
#include<string>
#include<algorithm>
using namespace std;

bool palindrome( int n);

int main ( )
{	
	int x;
	
	cout<<"x      x*x     x*x*x"<<endl;
	for(x=10;x<=1000;x++)
		if(palindrome(x) && palindrome(x*x) && palindrome(x*x*x))
			cout<< x << setw(8) << x*x << setw(10) <<x*x*x <<endl ;
	
	system("pause"); 
	return  0; 
}

bool palindrome( int  n)
{
	string s;
	s=to_string(n);
	reverse(s.begin(),s.end());
	int t;
	t=stoi(s);
	return  n==t;
	
}
