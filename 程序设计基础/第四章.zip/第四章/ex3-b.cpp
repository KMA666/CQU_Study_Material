// Ex3-b.cpp

extern  int  x, y;

int add( )         
{	
	return  x+y;
}
