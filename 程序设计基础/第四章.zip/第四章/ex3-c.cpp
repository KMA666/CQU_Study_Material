#include  <iostream>
using namespace std;

void  showArea ( float  length = 20.0, float  width = 10.0) ;

int  main ( )
{	
	showArea( );
	showArea(12.0);
	showArea(12.0, 5.5 );

	return 0;
}

void  showArea ( float  length, float  width)
{         	
	float  area = length * width ;

	cout << "The area is: " << area << endl ;
}