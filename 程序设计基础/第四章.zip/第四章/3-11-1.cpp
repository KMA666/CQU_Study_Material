#include  <iostream>
using namespace std;

template  < class  T >
T  add ( T  number1,T number2 ) 
{
	return  number1 + number2 ;
}

int  main ( )
{
	cout<<add(2,3)<<endl;
	cout<<add(1.3,3.4)<<endl;
	cout<<add("hello,","world!")<<endl;
	return 0; 
}


