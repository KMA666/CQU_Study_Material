
#include <iostream>
using namespace std;
int main ( )
{	
	int x=5;
	cout<<"x="<<x<<endl;
	int& y=x;
	cout<<"y="<<y<<endl;
	y++;
	cout<<"x="<<x<<endl;	
	return 0; 
} 
