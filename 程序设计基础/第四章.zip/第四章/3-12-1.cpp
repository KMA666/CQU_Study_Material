#include  <iostream>
using namespace std;
template  < class   T1 , class   T2>
void   swap ( T1   &var1 , T2   &var2 ) 
{  T1  temp ;
	temp = var1 ;
	var1 = ( T1 ) var2 ;
	var2 = ( T2 ) temp ;
} 
int main()
{
	int a;
	double b;
	cin>>a>>b;
	swap(a,b);
	cout<<a<<" "<<b<<endl;
	return 0;
}

