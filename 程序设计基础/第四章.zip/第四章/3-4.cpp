#include <iostream>
#include <iomanip>
using namespace std;

bool palindrome( int n);

int main ( )
{	
    int x;

    cout<<"x      x*x     x*x*x"<<endl;
    for(x=10;x<=1000;x++)
        if(palindrome(x) && palindrome(x*x) && palindrome(x*x*x))
            cout<< x << setw(8) << x*x << setw(10) <<x*x*x <<endl ;

    system("pause"); 
    return  0; 
}

bool palindrome( int  n)
{
    int  m=0, t=n;

    while( n != 0 )
    {
        m=m*10+n%10;
        n/=10;
    }

    return  m==t;
}