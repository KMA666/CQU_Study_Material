#include <iostream>
#include <iomanip>
using namespace std;
int     a; 
void  fun( ) 
{ 
	cout << setw(6) <<a <<" "<<&a<<endl; 
	a = 200; 
} 
int  main ( )
{	
	int  a = 10;
	
	fun( ); 
	cout << setw(6) << a <<" "<<&a << setw(6) << ::a << " "<<&(::a)<<endl; 
	
	return  0; 
}

