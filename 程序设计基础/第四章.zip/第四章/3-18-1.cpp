#include <iostream>
#define NUMBER 5
using namespace std;

int main() {
#if NUMBER == 10
	cout << "Number is equal to 10." << endl;
#elif NUMBER == 5
	cout << "Number is equal to 5." << endl;
#else
	cout << "Others." << endl;
#endif
	return 0;
}