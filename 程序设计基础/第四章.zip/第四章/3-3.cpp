#include <iostream>
#include <iomanip>
using namespace std;

void swap(int x, int y);

int main ( )
{    
    int a=10, b=20;
	cout<<"before swap(main):"<<endl;
	cout<< setw(6) << a << setw(6) <<b << endl ;
    swap(a, b);
	cout<<"after swap(main):"<<endl;
    cout<< setw(6) << a << setw(6) <<b << endl ;
    system("pause"); 
    return 0; 
}

void swap(int x, int y)
{    
    int t;
    
    t=x;    
    x=y;    
    y=t;
	cout<<"swap"<<endl;
    cout<< setw(6) << x << setw(6) <<y << endl ;
}
