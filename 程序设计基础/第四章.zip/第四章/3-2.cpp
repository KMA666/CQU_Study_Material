#include <iostream>
#include <cmath>
using namespace std;

bool prime( int  x );    // ����ԭ��

int main ( )
{    
    int x, n;
    
    for (n=960; n<=970; n=n+2)
        for (x=2; x<=n/2; x++)
             if ( prime(x) && prime(n-x))    // ��������
             {    
                  cout << n << " = "<< x << " + "<< n-x<<endl;
                  break;     
             }

    system("pause"); 
    return 0; 
}

bool prime(int x)    // ��������
{    
    int i, k;
      
    k=(int)sqrt(1.0 * x);
    for (i=2; i<=k; i++)
        if (x%i==0) 
             return false;

    return true;
}
