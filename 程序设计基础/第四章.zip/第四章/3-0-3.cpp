#include <iostream>
#include <iomanip>
#include<string>
#include<algorithm>
using namespace std;
int     a; 
void  fun( ) 
{ 
	cout << a ; 
	a = 200; 
} 
int  main ( )
{	
	int  a = 10;
	
	fun( ); 
	cout << setw(6) << a << setw(6) << ::a << endl; 
	
	return  0; 
}

