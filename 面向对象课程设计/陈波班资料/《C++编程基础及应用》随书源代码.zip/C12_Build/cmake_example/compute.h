#ifndef _COMPUTE_H
#define _COMPUTE_H

#define PI 3.1415926  //comment
#define SQUARE(x)  x*x
float circleArea(const float r);

#endif