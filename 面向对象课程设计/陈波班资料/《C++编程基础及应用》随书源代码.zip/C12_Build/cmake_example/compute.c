#include "compute.h"
#include "compute.h"

float circleArea(const float r){
    float t = PI * SQUARE(r);  //comment
    return t;
}
