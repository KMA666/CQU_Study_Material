#include <stdio.h>
#include "compute.h"

int main(){
    float r = 4.1f;
    float a = circleArea(r);   //comment
    printf("Area of the circle = %f.\n",a);
}