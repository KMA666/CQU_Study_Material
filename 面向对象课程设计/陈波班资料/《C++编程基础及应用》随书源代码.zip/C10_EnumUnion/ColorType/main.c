//Project - ColorType
//enumeration  枚举
enum ColorType {
    red,orange,yellow=100,green,blue,violet
};//注意末尾的分号不能少
//  0   1      100        101   102  103

const char* getColor(enum ColorType c){
    switch (c){
    case red:
        return "red";
    case orange:
        return "orange";
    case yellow:
        return "yellow";
    case green:
        return "green";
    case blue:
        return "blue";
    case violet:
        return "violet";
    default:
        return "error";
    }
}

int main(){
    enum ColorType color = blue;
    color = green;
    color = 999;   //编译器警告：999不存枚举范围内
    color = 1;     //等价于orange
    color = (enum ColorType)103;  //等价于violet
    printf("violt = %d\n",violet);
    printf("color = %s\n",getColor(green));
}

