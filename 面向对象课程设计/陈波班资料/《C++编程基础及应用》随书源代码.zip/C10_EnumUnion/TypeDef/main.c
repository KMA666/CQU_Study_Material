//Project - TypeDef
#include <stdio.h>

typedef unsigned char  UINT8;    //无符号8位整数   unsigned int of 8 bits
typedef unsigned short UINT16;   //无符号16位整数
typedef unsigned int   UINT32;   //无符号32位整数

typedef char  INT8;              //有符号8位整数
typedef short INT16;             //有符号16位整数
typedef int   INT32;             //有符号32位整数

int main() {
    UINT8 b = 0x77;             //b的类型实为unsigned char
    UINT16 s = 0xf900;          //s的类型实为unsigned short
    INT32 c = 0x1f2f3f4f;       //c的类型实为int

    printf("sizeof(b) = %lld, sizeof(s) = %lld, sizeof(c) = %lld\n",
           sizeof(b), sizeof(s), sizeof(c));

    return 0;
}
