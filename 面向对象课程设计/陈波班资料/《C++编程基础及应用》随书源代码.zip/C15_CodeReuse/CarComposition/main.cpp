//Project - CarComposition
#include <iostream>
using namespace std;

class Wheel {
public:
    short iWheelSize;  //轮胎尺寸
    Wheel(){
        cout << "Wheel Constructed." << endl;
    }
    ~Wheel(){
        cout << "Wheel Destructed." << endl;
    }
};

class Engine {
private:
    int iCapacity;   //发动机排量
public:
    Engine(int capacity){
        iCapacity = capacity;
        cout << "Engine Constructed." << endl;
    }
    ~Engine(){
        cout << "Engine Destructed." << endl;
    }
};

class Car {
public:
    Engine e;
    Wheel wheels[4];
    int iWeight;    //整车重量
    //...

    Car(int weight):e(1800), iWeight(weight){
        //e.start() ...
        cout << "Car Constructed." << endl;
    }

    ~Car(){
        cout << "Car Destructed." << endl;
        //e.stop() ...
    }
};

int main() {
    printf("sizeof(Engine) + 4 x sizeof(Wheel) + sizeof(int)\n");
    printf("= %d + 4 x %d + %d\n", sizeof(Engine), sizeof(Wheel), sizeof(int));
    printf("= %d\n",sizeof(Car));
    cout << "--------------------------------------" << endl;

    Car c(2300);
    cout << "--------------------------------------" << endl;
    printf("&c = %p, &c.e = %p\nc.wheels = %p, &c.iWeight = %p\n",
           &c, &c.e, c.wheels, &c.iWeight);
    cout << "--------------------------------------" << endl;

    return 0;
}
