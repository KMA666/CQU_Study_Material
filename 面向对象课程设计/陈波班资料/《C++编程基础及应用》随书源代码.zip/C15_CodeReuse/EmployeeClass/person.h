#ifndef PERSON_H
#define PERSON_H

#include <string>
using namespace std;

enum class GenderType{
    male = 0, female = 1
};

class Person{
private:
    int iWeight {50000};    //体重，以克为单位

protected:
    string sName;           //姓名
    string sID;             //身份证号
    GenderType gender = GenderType::female; //性别
    void speak();

public:
    Person(const string& id, const string& name);
    void eat(int weight);
    string description();
    ~Person();
};  //注意末尾的分号不能少

#endif // PERSON_H
