//Project - EmployeeClass
#include <iostream>
#include <employee.h>
using namespace std;

int main() {
    cout << "---------------------construct----------------" << endl;
    Employee dora("10001","36040200001","Dora Henry");
    dora.sDepartment = "Marketing";
    dora.sJobTitle = "Sales";

    cout << "---------------------memory map---------------" << endl;
    printf("sizeof(Employee) = sizeof(Person) + 3 x sizeof(string)"
           "\n=%lld + 3 x %lld\n=%lld\n",
           sizeof(Person),sizeof(string),sizeof(Employee));

    Person* pDora = &dora; //通过向上类型转换获得dora对象内的父对象地址
    printf("&dora = %p\n&(Parent Object) = %p\n&dora.sEmployeeNo = %p"
           "\n&dora.sJobTitle = %p\n&dora.sDepartment = %p\n",
           &dora, pDora, &dora.sEmployeeNo,&dora.sJobTitle,&dora.sDepartment);

    cout << "---------------------work---------------------" << endl;
    dora.work();
    cout << "---------------------speak--------------------" << endl;
    dora.speak();
    cout << "---------------------eat----------------------" << endl;
    dora.eat(220);
    cout << "---------------------description--------------" << endl;
    cout << dora.description() << endl;

    cout << "---------------------destruct-----------------" << endl;
    return 0;
}

