#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include "person.h"

class Employee:public Person
{
public:
    string sEmployeeNo;
    string sJobTitle;
    string sDepartment;

    Employee(const string& emplNo, const string& id, const string& name);
    ~Employee();

    void work();
    void speak();
    string description();
};

#endif // EMPLOYEE_H
