//Project - SimpleGUI
#include "widget.h"
#include <QApplication>
#include <QPushButton>

int main(int argc, char *argv[]){
    QApplication a(argc, argv);
    Widget w;

    w.setGeometry(200,200,600,400);
    w.setWindowTitle("GUI, Let's embrace the world!");

    auto btnExit = new QPushButton("Exit",&w);
    btnExit->resize(200,80);
    btnExit->move(200,160);
    btnExit->connect(btnExit,SIGNAL(released()),&a,SLOT(quit()));

    w.show();
    return a.exec();
}
