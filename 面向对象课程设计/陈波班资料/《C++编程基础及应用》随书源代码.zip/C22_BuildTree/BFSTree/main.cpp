//Project - BFSTree
#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class TreeNode {
public:
    string sLabel;
    vector<TreeNode*> children;
    TreeNode(const string& label){
        sLabel = label;
    }

    ~TreeNode(){
        cout << "~TreeNode() of " << sLabel << endl;
        for (auto x:children)
            delete x;
    }
};

void bfs(const TreeNode* root){
    queue<const TreeNode*> q;
    q.push(root);

    while (!q.empty()){
        const TreeNode* t = q.front();
        q.pop();
        cout << "found " << t->sLabel << endl;
        for (auto& x:t->children)
            q.push(x);
    }
}

int main() {
    auto a = new TreeNode("A");
    auto b = new TreeNode("B");
    auto c = new TreeNode("C");
    auto d = new TreeNode("D");
    auto e = new TreeNode("E");
    auto f = new TreeNode("F");
    a->children.push_back(b);
    a->children.push_back(d);
    b->children.push_back(c);
    d->children.push_back(e);
    e->children.push_back(f);

    bfs(a);

    delete a;
    return 0;
}
