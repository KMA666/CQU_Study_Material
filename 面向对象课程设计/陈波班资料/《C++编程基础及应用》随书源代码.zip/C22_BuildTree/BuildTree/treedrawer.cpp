#include "treedrawer.h"
#include "math.h"
#include <QPainter>
#include <QDebug>
#include <QResizeEvent>
#include <QQueue>

TreeDrawer::TreeDrawer(QWidget *parent)
    : QWidget{parent} {
    qDebug() << "TreeDrawer::TreeDrawer(), ptr = " << this;
}

TreeDrawer::~TreeDrawer(){
    qDebug() << "TreeDrawer::~TreeDrawer(), ptr = " << this;
    if (root)
        delete root;
}

void TreeDrawer::drawBranch(const TreeNode* t, QPainter& painter){
    //分成小段画树支，模拟粗糙弯曲效果
    auto g = 0x60*t->depth/TreeNode::maxDepth;
    painter.setPen(QPen(QColor(g,g,g),pow((TreeNode::maxDepth-t->depth),1.5)));

    auto& btm = t->bottom;
    auto& top = t->drawingTop;

    const int iDist = 10;
    double dx = top.x() - btm.x();
    double dy = top.y() - btm.y();
    double c = sqrt(dx*dx+dy*dy);
    auto n = int(c/iDist);
    double xPrev = btm.x();
    double yPrev = btm.y();
    for (auto i=1;i<n;i++){
        auto x = t->bottom.x() + dx*i/n;
        auto y = t->bottom.y() + dy*i/n;
        x += iDist*(0.5-double(rand())/RAND_MAX)*0.13;
        y += iDist*(0.5-double(rand())/RAND_MAX)*0.13;
        painter.drawLine(QPointF(xPrev,height()-yPrev),QPointF(x,height()-y));
        xPrev = x;
        yPrev = y;
    }
    painter.drawLine(QPointF(xPrev,height()-yPrev),QPointF(top.x(),height()-top.y()));
}

void TreeDrawer::drawNode(const TreeNode* t, QPainter& painter){
    drawBranch(t,painter);

    if (t->isLeaf()){
        //对于叶子节点，画树叶
        auto& top = t->drawingTop;
        auto red = 0xf0 * rand()/RAND_MAX;
        painter.setBrush(QBrush(QColor(red,0x90,0x00)));
        painter.drawEllipse(QPointF(top.x(), height()-top.y()),3,3);
    }
}

void TreeDrawer::paintEvent(QPaintEvent* e){
    QPainter painter;
    painter.begin(this);

    if (root){
        //宽度优先遍历树的全部节点并逐一绘制
        QQueue<TreeNode*> q;
        q.enqueue(root);

        while (!q.empty()){
            auto t = q.dequeue();
            drawNode(t,painter);
            for (auto& x:t->children)
                q.enqueue(x);
        }
    }

    painter.end();
}

void TreeDrawer::newTree(){
    //删除旧树，创建新树
    if (root){
        delete root;
        root = nullptr;
    }
    auto btm  = QPoint(width()/2,20);
    auto top = QPoint(int(width()/2),int(height()*0.9));
    root = new TreeNode(btm,top);
    update();
}

void TreeDrawer::resizeEvent(QResizeEvent* e){
    qDebug() << "TreeDrawer::resizeEvent, w=" << width() << ",h=" << height();
    newTree();
}
