#include "mainwidget.h"
#include "ui_mainwidget.h"
#include "treedrawer.h"
#include "gridselection.h"

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainWidget)
{
    ui->setupUi(this);
    treeDrawer = new TreeDrawer(this);
    ui->layoutDrawer->addWidget(treeDrawer);
}

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::on_pbRefresh_released()
{
    treeDrawer->newTree();
}

void MainWidget::on_pbLevels_released() {
    QVector<QString> options {"2", "3", "4", "5", "6", "7", "8", "9"};
    GridSelection* dlg = new GridSelection(options,this,ui->pbLevels->text());
    dlg->setWindowTitle("Options for tree levels");
    dlg->exec();
    auto sResult = dlg->strSelected;
    delete dlg;

    if (sResult == "")
        return;

    ui->pbLevels->setText(sResult);
    TreeNode::maxDepth = sResult.toInt()-1;
    treeDrawer->newTree();
}

void MainWidget::on_pbBranches_released() {
    QVector<QString> options {"2", "3", "4", "5"};
    GridSelection* dlg = new GridSelection(options, this,ui->pbBranches->text());
    dlg->setWindowTitle("Options for average number of branches");
    dlg->exec();
    auto sResult = dlg->strSelected;
    delete dlg;

    if (sResult == "")
        return;

    ui->pbBranches->setText(sResult);
    TreeNode::nBranches = sResult.toInt();
    treeDrawer->newTree();
}

