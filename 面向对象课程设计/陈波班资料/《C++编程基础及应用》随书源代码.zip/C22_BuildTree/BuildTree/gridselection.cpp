#include "gridselection.h"
#include "ui_gridselection.h"

GridSelection::GridSelection(const QVector<QString>& options,
                             QWidget *parent, QString sCurrent):
    QDialog(parent),
    ui(new Ui::GridSelection){
    ui->setupUi(this);
    this->options = options;
    initGrid(sCurrent);
    setFixedSize(width(),height());
}

GridSelection::~GridSelection(){
    delete ui;
}

void GridSelection::on_pbCancel_released(){
    close();
}

void GridSelection::on_tableWidget_cellClicked(int row, int column){
    if (ui->tableWidget->item(row, column)->text() == "")
        return;

    strSelected = ui->tableWidget->item(row, column)->text();
    close();
}

void GridSelection::initGrid(QString sCurrent){
    int size = int(options.size());
    auto tw = ui->tableWidget;
    if(size <= 12){
        tw->setRowCount(size);
        tw->setColumnCount(1);
    }
    else if(size <= 12*10){
        int rCount = (size%10 == 0) ? size/10 : (size/10)+1;
        tw->setRowCount(rCount);
        tw->setColumnCount(10);
    }
    else if(size <= 15*13){
        int rCount = (size%13 == 0) ? size/13 : (size/13)+1;
        tw->setRowCount(rCount);
        tw->setColumnCount(13);
    }
    else {
        int rCount = (size%20 == 0) ? size/20 : (size/20)+1;
        tw->setRowCount(rCount);
        tw->setColumnCount(20);
    }

    int w = tw->width() / tw->columnCount();
    int h = tw->height() / tw->rowCount();
    h = (h>50) ? 50 : h;

    for (int c=0; c<tw->columnCount(); c++){
        tw->setColumnWidth(c,w);
        for (int r=0; r<tw->rowCount(); r++){
            tw->setRowHeight(r,h);

            auto itm = new QTableWidgetItem();
            itm->setTextAlignment(Qt::AlignHCenter|
                                  Qt::AlignVCenter|Qt::AlignCenter);
            int i = r*tw->columnCount() + c;
            if (i < size){
                itm->setText(options[i]);
                tw->setItem(r,c,itm);
                if (options[i] == sCurrent)
                    tw->setCurrentCell(r,c);
            }
            else {
                itm->setFlags(Qt::NoItemFlags);
                itm->setText("");
                tw->setItem(r,c,itm);
            }
        }
    }
}

