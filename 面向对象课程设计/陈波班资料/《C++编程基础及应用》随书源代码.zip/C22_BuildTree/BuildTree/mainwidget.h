#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include "treedrawer.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWidget; }
QT_END_NAMESPACE

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    MainWidget(QWidget *parent = nullptr);
    ~MainWidget();

private slots:
    void on_pbRefresh_released();
    void on_pbLevels_released();
    void on_pbBranches_released();

private:
    Ui::MainWidget *ui;
    TreeDrawer* treeDrawer = nullptr;
};
#endif // MAINWIDGET_H
