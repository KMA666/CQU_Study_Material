#ifndef TREEDRAWER_H
#define TREEDRAWER_H

#include <QWidget>
#include "treenode.h"

class TreeDrawer : public QWidget
{
    Q_OBJECT
private:
    void paintEvent(QPaintEvent* e);
    TreeNode* root = nullptr;
    void resizeEvent(QResizeEvent* e);
    void drawNode(const TreeNode* t, QPainter& painter);
    void drawBranch(const TreeNode* t, QPainter& painter);

public:
    explicit TreeDrawer(QWidget *parent = nullptr);
    virtual ~TreeDrawer();
    void newTree();

signals:
};

#endif // TREEDRAWER_H
