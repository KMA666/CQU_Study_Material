#ifndef TREENODE_H
#define TREENODE_H
#include <QPoint>
#include <QVector>

class TreeNode {
private:
    QPoint bottom;
    QPoint top;
    QPoint drawingTop;
    int depth;
    QVector<TreeNode*> children;
    void generateDescendents();
    TreeNode* bornSon(const QPoint& btm, const QPoint& top, double angleOffset);

public:
    static int maxDepth;
    static int nBranches;
    TreeNode(const QPoint& btm, const QPoint& top, int depth=0);
    ~TreeNode();

    bool isLeaf() const{
        return children.empty();
    }

    friend class TreeDrawer;
};

#endif // TREENODE_H
