#ifndef GRIDSELECTION_H
#define GRIDSELECTION_H
#include <QDialog>

namespace Ui {
class GridSelection;
}

class GridSelection : public QDialog
{
    Q_OBJECT
public:
    explicit GridSelection(const QVector<QString>& options,
                           QWidget *parent = nullptr, QString sCurrent = "");
    ~GridSelection();
    QVector<QString> options;
    QString strSelected = "";

public slots:
    void on_pbCancel_released();
    void on_tableWidget_cellClicked(int row, int column);

private:
    Ui::GridSelection *ui;
    void initGrid(QString sCurrent);
};

#endif // GRIDSELECTION_H
