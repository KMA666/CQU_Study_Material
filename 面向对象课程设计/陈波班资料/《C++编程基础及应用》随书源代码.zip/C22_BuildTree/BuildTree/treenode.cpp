#include "treenode.h"
#include <random>
#include <math.h>
#include <QDebug>

int TreeNode::maxDepth = 7;
int TreeNode::nBranches = 3;

TreeNode::TreeNode(const QPoint& btm, const QPoint& top, int depth){
    bottom = btm;
    this->top = top;
    this->depth = depth;
    generateDescendents();

//    qDebug() << "Create tree node, " << btm.x() << "," << btm.y()
//             << "-->" << top.x() << "," << top.y() << " ,depth=" << depth;
}

void TreeNode::generateDescendents(){
    //递归地生成节点的子节点及后代
    const double pi = 3.1415926535897932;
    int n = int(round(nBranches*(0.5 + rand() / double(RAND_MAX))));
    n = (n>=1?n:1);

    double r = 0.2 + rand()/double(RAND_MAX) * 0.2;
    drawingTop.setX(bottom.x() + int((top.x()-bottom.x())*r));
    drawingTop.setY(bottom.y() + int((top.y()-bottom.y())*r));
    if (depth<maxDepth){
        double a = pi * 0.5 / n;
        for (auto i=0;i<n;i++){
            double angleOffset = a*((n-1)/2.0 - i);
            angleOffset *= (0.9 + rand()/double(RAND_MAX) * 0.2);
            auto t = bornSon(drawingTop, top, angleOffset);
            children.push_back(t);
        }
    }
}

TreeNode* TreeNode::bornSon(const QPoint& btm, const QPoint& top,
                            double angleOffset){
    //为当前节点生成一个子节点，其偏移角为angleOffset
    int dx = top.x() - btm.x();
    int dy = top.y() - btm.y();
    Q_ASSERT(!(dx==0 && dy==0));
    double angleSubTree = atan2(dy,dx);
    double angleSon = angleSubTree + angleOffset;
    double r = 0.9 + 0.2*rand()/RAND_MAX;
    double c = sqrt(dx*dx+dy*dy) * r;
    int xOffset = int(c*cos(angleSon));
    int yOffset = int(c*sin(angleSon));
    QPoint topNew(btm.x() + xOffset,btm.y()+yOffset);
    return new TreeNode(btm,topNew,depth+1);
}

TreeNode::~TreeNode(){
    //递归地删除全部子节点
    for (auto n:children)
        delete n;
}

