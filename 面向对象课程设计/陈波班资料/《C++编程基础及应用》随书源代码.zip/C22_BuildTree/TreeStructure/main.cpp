//Project - TreeStructure
#include <iostream>
#include <vector>
using namespace std;

class TreeNode {
public:
    string sLabel;
    vector<TreeNode*> children;
    TreeNode(const string& label){
        sLabel = label;
    }

    ~TreeNode(){
        cout << "~TreeNode() of " << sLabel << endl;
        for (auto x:children)
            delete x;
    }
};

int main() {
    auto a = new TreeNode("a");
    auto b = new TreeNode("b");
    a->children.push_back(b);
    a->children.push_back(new TreeNode("c"));
    a->children.push_back(new TreeNode("d"));
    b->children.push_back(new TreeNode("e"));
    b->children.push_back(new TreeNode("f"));
    delete a;
    return 0;
}
