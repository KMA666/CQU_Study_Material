//Project - VPTR
#include <iostream>
using namespace std;

class NoVirtual {
public:
    long long iDummy;    //占8个字节
    ~NoVirtual(){
        cout << "~NoVirtual" << endl;
    }
};

class WithVirtual{
public:
    long long iDummy;    //占8个字节
    virtual ~WithVirtual(){
        cout << "~WithVirtual" << endl;
    }
};

int main() {
    cout << "sizeof(NoVirtual) = " << sizeof(NoVirtual) << endl;
    cout << "sizeof(WithVirtual) = " << sizeof(WithVirtual) << endl;
    WithVirtual a,b;
    printf("&a = %p, &a.iDummy = %p\n", &a, &a.iDummy);
    printf("vptr of a = %p, vptr of b = %p\n",
           *(unsigned long long*)&a, *(unsigned long long*)&b);
    return 0;
}
