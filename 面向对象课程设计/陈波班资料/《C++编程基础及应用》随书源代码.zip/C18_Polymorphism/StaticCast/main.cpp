//Project - StaticCast
#include <iostream>
using namespace std;

class Pet{};
class Cat:public Pet{};
class Dog:public Pet{};

int main(){
    int v = 77;
    long long ll = static_cast<long long>(v);//int --> long long
    float f = static_cast<float>(v);         //int --> float
    unsigned char uc = static_cast<unsigned char>(v); //允许但有风险
    //float* p = static_cast<float*>(&v);    //错误:int* --> float*

    Cat c;
    Pet p = static_cast<Pet>(c);	   //Cat --> Pet
    Pet& p1 = static_cast<Pet&>(c);    //Cat --> Pet&
    Pet* p2 = static_cast<Pet*>(&c);   //Cat* --> Pet*
    Cat* c1 = static_cast<Cat*>(p2);   //Pet* --> Cat*, 允许但不安全
    //Cat c2 = static_cast<Cat>(p);    //错误:Pet --> Cat

    return 0;
}
