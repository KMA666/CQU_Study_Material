//Project - RTTI
#include <iostream>
#include <typeinfo>
using namespace std;

class Shape{public: ~Shape(){}};
class Circle:public Shape{};

class Pet{public: virtual ~Pet(){}};
class Rabbit:public Pet{};

int main(){
    Shape *s = new Circle();
    if (typeid(*s) == typeid(Shape))
        cout << "s points to a shape." << endl;
    if (typeid(*s) == typeid(Circle))
        cout << "s points to a circle." << endl;

    Pet *p = new Rabbit();
    if (typeid(*p)==typeid(Pet))
        cout << "p points to a pet." << endl;
    if (typeid(*p)==typeid(Rabbit))
        cout << "p points to a rabbit." << endl;

    return 0;
}
