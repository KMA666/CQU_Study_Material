//Project - EarlyBinding
#include <iostream>
#include <string>
using namespace std;

class Pet {
public:
    string sName;
    void sayHello() {
        cout << "Pet " << sName << " : hello" << endl;
    }

    Pet(const string& name):sName(name){}
    ~Pet(){
        cout << "Pet destructor: " << sName << endl;
    }
};

class Rabbit:public Pet {
public:
    void sayHello(){
        cout << "Rabbit " << sName << " : carrot" << endl;
    }

    Rabbit(const string& name):Pet(name){}
    ~Rabbit(){
        cout << "Rabbit destructor: " << sName << endl;
    }
};

class Cat:public Pet {
public:
    void sayHello(){
        cout << "Cat " << sName << " : meow " << endl;
    }

    Cat(const string& name):Pet(name){}
    ~Cat(){
        cout << "Cat destructor: " << sName << endl;
    }
};

int main(){
   Rabbit r("Charlie");       //查理兔
   Pet&  r2 = r;
   r2.sayHello();

   Pet* c = new Cat("Lucy");  //露西猫
   c->sayHello();
   delete c;
   return 0;
}
