//Project - Word
#include <iostream>
using namespace std;

class Shape {
public:
    //virtual Size getSize() = 0;
    virtual void draw() = 0;
    virtual ~Shape(){}
};

class Triangle:public Shape{
public:
    //point0, point1, point2
    //Size getSize(...)
    //float getArea(...)
    void draw(){ cout << "Triangle::draw()" << endl; }
};

class Circle:public Shape{
public:
    //ptCenter, iRadius
    //Size getSize(...)
    //float getArea(...)
    void draw() { cout << "Circle::draw()" << endl; }
};

class Paragraph:public Shape{
public:
    string sContent;
    //Size getSize(...)
    //void setFont(...)
    void draw(){ cout << "Paragraph::draw()" << endl; }
};

void renderDocument(Shape* shapes[], int n){
    for (auto i=0; i<n;i++)
        shapes[i]->draw();
}

int main(){
    Shape* shapes[] = {new Triangle(),new Triangle(),new Circle(),
                      new Circle(), new Paragraph()};

    renderDocument(shapes,5);

    for (auto x:shapes)
        delete x;
    return 0;
}
