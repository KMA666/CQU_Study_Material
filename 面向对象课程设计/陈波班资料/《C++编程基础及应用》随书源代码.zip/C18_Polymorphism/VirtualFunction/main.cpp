//Project - VirtualFunction
#include <iostream>
#include <string>
using namespace std;

class Pet {
public:
    string sName;
    virtual void sayHello() {
        cout << "Pet " << sName << " : hello" << endl;
    }

    Pet(const string& name):sName(name){}
    virtual ~Pet(){
        cout << "Pet destructor: " << sName << endl;
    }
};

class Rabbit:public Pet {
public:
    virtual void sayHello(){   //virtual可省略
        cout << "Rabbit " << sName << " : carrot" << endl;
    }

    Rabbit(const string& name):Pet(name){}
    virtual ~Rabbit(){         //virtual可省略
        cout << "Rabbit destructor: " << sName << endl;
    }
};

class Cat:public Pet {
public:
    virtual void sayHello(){  //virtual可省略
        cout << "Cat " << sName << " : meow " << endl;
    }

    Cat(const string& name):Pet(name){}
    virtual ~Cat(){          //virtual可省略
        cout << "Cat destructor: " << sName << endl;
    }
};

int main(){
   Rabbit r("Charlie");       //查理兔
   Pet&  r2 = r;
   r2.sayHello();

   Pet* c = new Cat("Lucy");  //露西猫
   c->sayHello();
   delete c;
   return 0;
}
