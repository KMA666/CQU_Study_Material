//Project - TriangleArea
#include <iostream>
#include <exception>
#include <cmath>
using namespace std;

class NotTriangle:public exception {
    int a,b,c;
public:
    NotTriangle(int x,int y,int z){ a=x; b=y; c=z; }

    virtual const char* what() const noexcept{
        static char sInfo[256];
        sprintf(sInfo,"<%d,%d,%d> it not a triangle.",a,b,c);
        return sInfo;
    }
};

double compTriangleArea(int a, int b, int c){
    if (a==0 || b==0 || c==0)
        throw 0;  //抛出异常，异常对象为整数0

    if (a<0 || b<0 || c<0)
        throw "invalid negative side length."; //抛出异常，异常对象类型为const char*

    if (a+b>c && a+c>b && b+c>a){
        auto p = (a+b+c)/2.0;
        auto s = sqrt(p*(p-a)*(p-b)*(p-c));
        return s;  //函数正常返回
    }
    else
        throw NotTriangle(a,b,c); //抛出异常，异常对象类型为NotTriangle
}

int main(){
    int a,b,c;
    cout << "Enter side lengths a, b, c of the triangle:\n";

    while (cin>>a>>b>>c){
        try {
            auto r = compTriangleArea(a,b,c);
            cout << "Area of the triangle:" << r << endl;
        }
        catch (const NotTriangle& e) {
            cout << "Exception caught & processed: " << e.what() << endl;
        }
        catch (const char* s){
            cout << "Exception caught & processed: " << s << endl;
        }
        catch (const int e){
            cout << "Exception caught & processed: " << e << endl;
        }
        catch (...){
            cout << "catch (...) is used to catch all uncaught exceptions.\n";
        }
    }

    cout << "Program terminated normally." << endl;
    return 0;
}

