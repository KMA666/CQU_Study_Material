//Project - CellCounter
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

bool readCellPicture(vector<vector<int>>& d, int& m, int& n){
    string s;

    ifstream in("D:/C2Cpp/C21_Exception/CellCounter/cellpicture.txt");
    in >> m >> n;
    getline(in,s);

    d.resize(m);
    for (int i=0;i<m;i++){
        getline(in,s);
        if (s.size()!=n)
            return false;
        vector<int>& r = d[i];
        r.resize(n);
        for (int j=0;j<n;j++)
            r[j] = s[j]-'0';
    }

    return true;
}

void explorePixel(vector<vector<int>>& d,const int m, const int n,const int i, const int j)
{
    queue<pair<int,int>> q;
    q.push(std::make_pair(i,j));

    while (!q.empty()){
        auto& e = q.front();
        int x = e.first, y = e.second;
        q.pop();
        if (d[x][y]<0)
            continue;
        d[x][y] = 0 - d[x][y];
        if (x>0 && d[x-1][y]>0)
            q.push(make_pair(x-1,y));
        if (x<(m-1) && d[x+1][y]>0)
            q.push(make_pair(x+1,y));
        if (y>0 && d[x][y-1]>0)
            q.push(make_pair(x,y-1));
        if (y<(n-1) && d[x][y+1]>0)
            q.push(make_pair(x,y+1));
    }

    return;
}

int main()
{
    int m=0,n=0;
    vector<vector<int>> d;
    if (!readCellPicture(d,m,n)){
        cout << "Read cellpicture.txt failed." << endl;
        return 0;
    }

    int iCellCount = 0;
    for (int i=0;i<m;i++)
        for (int j=0;j<n;j++){
            if (d[i][j]<=0)
                continue;
            iCellCount+=1;
            explorePixel(d,m,n,i,j);
        }

    cout << "Found " << iCellCount << " cells.";
    return 0;
}
