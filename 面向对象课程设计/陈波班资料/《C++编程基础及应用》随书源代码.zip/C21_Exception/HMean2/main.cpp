//Project - HMean2
#include <iostream>
using namespace std;

bool hmean(int a, int b, float& r){
    if (a==-b)
        return false;

    r = 2.0f * a * b / (a + b);
    return true;
}

int main(){
    int x = 0, y = 0;
    float z = 0.0f;

    cout << "Enter two numbers:" << endl;
    while (cin >> x >> y){
        auto r = hmean(x,y,z);
        if (r)
            cout << "hmean(" << x << "," << y << ") = " << z << endl;
        else
            cout << "hmean() failed unexpectedly." << endl;
    }

    cout << "Program terminated normally." << endl;
    return 0;
}
