//Project - StackUnwinding
#include <iostream>
using namespace std;

class Marker{
    string sName;
public:
    Marker(string name){
        sName = name;
        cout << "Marker " << sName << " constructed.\n";
    }

    ~Marker(){
        cout << "Marker " << sName << " destructed.\n";
    }
};

int B(){
    Marker b1("b1");
    throw "user defined exception";
    Marker b2("b2");
    return 0;
}

void A(){
    Marker a1("a1");
    B();
    cout << "Function B returned.\n";
    Marker a2("a2");
}

int main(){
    try {
        Marker m1("m1");
        A();
        Marker m2("m2");
    }
    catch (const char* s){
        cout << "Exception caught & processed: " << s << endl;
    }

    cout << "Program terminated normally.\n";
    return 0;
}


