//Project - HMean1
#include <iostream>
using namespace std;

float hmean(int a, int b){
    if (a==-b){
        cout << "invalid arguments for hmean()" << endl;
        abort();
    }
    return 2.0f * a * b / (a + b);
}

int main(){
    int x = 0, y = 0;
    float z = 0.0f;

    cout << "Enter two numbers:" << endl;
    while (cin >> x >> y){
        z = hmean(x,y);
        cout << "hmean(" << x << "," << y << ") = " << z << endl;
    }

    cout << "Program terminated normally." << endl;
    return 0;
}
