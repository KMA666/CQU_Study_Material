//Project - RefParameter
#include <iostream>
using namespace std;

void swap1(float& a, float& b){
    auto t = a;
    a = b;
    b = t;
}

double getCircleArea(const double& r){
    return 3.1415926 * r * r;
}

int main(){
    double m = 3.0, n = 4.0;
    //swap1(m,n);           //错误：无法将double类型引用为float&
    float c = 3.0f;
    //swap1(c, c+1.2f);     //错误：c+1.2f为临时对象，无确定的内存实体，无法传递引用

    double dArea = getCircleArea(7.6f);

    return 0;
}
