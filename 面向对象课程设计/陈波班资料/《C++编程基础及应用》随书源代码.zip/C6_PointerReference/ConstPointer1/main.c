//Project - ConstPointer1
#include <stdio.h>

int main(){
    const int a = 10;
    //int* p1 = &a;     //错误：a的地址为const int*，而p1是int*

    int b = 10;
    const int* p2 = &b;
    //*p2 = *p2 * 2;    //错误：p2指向const int，不可以修改*p2

    int c = 10, d = 11;
    const int* const p3 = &c;
    //*p3 = 101;        //错误：p3指向const int，不可修改*p3
    //p3 = &d;          //错误：p3自身是常量，不可修改其值改变其指向

    return 0;
}
