//Project - add
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv){   //char *argv[]
    for (int i=0;i<argc;i++)
        printf("%d: %s,  %p\n", i, argv[i], argv[i]);

    int iSum = 0;
    for (int i=1;i<argc;i++)
        iSum += atoi(argv[i]);

    printf("sum = %d",iSum);
    return 0;
}
