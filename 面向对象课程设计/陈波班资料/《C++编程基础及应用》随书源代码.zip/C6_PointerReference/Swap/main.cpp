//Project - Swap
#include <iostream>
using namespace std;

void swap1(int a, int b){
    int t = a;
    a = b;
    b = t;
}

void swap2(int* a, int* b){
    int t = *a;
    *a = *b;
    *b = t;
}

int main() {
    int m = 2, n = 7;

    swap1(m,n);
    cout << "after swap1: m = " << m << ", n = " << n << endl;

    swap2(&m, &n);
    cout << "after swap2: m = " << m << ", n = " << n << endl;

    return 0;
}
