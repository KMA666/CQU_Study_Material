//Project - BasicRef
#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    int iRabbits = 100;
    int& iBunnies = iRabbits;
    printf("&iRabbits = %p, &iBunnies = %p\n", &iRabbits, &iBunnies);

    iRabbits += 10;
    iBunnies += 5;

    cout << "iRabbits = " << iRabbits << ", iBunnies = " << iBunnies << endl;
    return 0;
}
