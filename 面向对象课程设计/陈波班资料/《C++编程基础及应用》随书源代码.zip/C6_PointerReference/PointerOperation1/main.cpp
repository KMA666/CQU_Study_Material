//Project - PointerOperation1
#include <cstdio>
#include <cstdlib>

int main(){
    float* p = (float*)calloc(10,sizeof(float));
    if (p==nullptr)
        exit(1);

    printf("p = %p,  p + 1 = %p,  p + 3 = %p\n", p, p+1, p+3);

    for (int i=0;i<10;i++)
        *(p++) = i;            //*p++结果相同
    p-=10;
    printf("p[0] = %f,  p[3] = %f,  p[9] = %f\n", *p,  *(p+3), *(p+9));

    free(p);                  //释放通过calloc()申请的内存
    return 0;
}
