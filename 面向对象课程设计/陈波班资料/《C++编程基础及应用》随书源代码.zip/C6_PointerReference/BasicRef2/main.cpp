//Project - BasicRef2
#include <iostream>
using namespace std;

int main(){
    int a = 3, b = 4;
    int* p = &a;
    p = &b;

    int c = 3, d = 4;
    int& r = c;  //必须在定义时初始化r，将其与特定的对象相绑定
    r = d;       //不是将r的指向改向d，而是把d赋值给r引用的变量c
    cout << "c = " << c << ", d = " << d <<", r = " << r << endl;

    float e = 3.14f;
    const float& f = e;
    e += 1.0;
    //f += 1.0;           //不可以修改常量型引用
    cout << "e = " << e << ", f = " << f;

    return 0;
}
