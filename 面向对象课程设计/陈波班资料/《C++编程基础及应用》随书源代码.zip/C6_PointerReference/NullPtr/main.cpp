//Project - NullPtr
#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    char c {'c'};
    char* p {nullptr};
    //*p = 'a';  //对一个空指针应用间接操作符会引发执行错误
    printf("p = nullptr = %p\n", p);
    p = &c;
    printf("p = &c = %p, c = %c, *p = %c", p, c, *p);

    return 0;
}
