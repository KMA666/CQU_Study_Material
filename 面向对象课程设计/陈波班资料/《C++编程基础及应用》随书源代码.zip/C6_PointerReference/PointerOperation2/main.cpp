//Project - PointerOperation2
#include <cstdio>
#include <cctype>

int main() {
    char s[] = "Mary has 3 lambs.";
    char* p = s;

    while (*p!=0){   //*p!=0 等价于 (*p)!=0
        if (islower(*p))
            *p = *p + ('A' - 'a');
        p++;
    }

    printf("s = %s",s);
    return 0;
}
