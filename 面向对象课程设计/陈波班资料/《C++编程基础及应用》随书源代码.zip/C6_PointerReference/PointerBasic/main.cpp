//Project - PointerBasic
#include <cstdio>

int main(){
    int a = 9999, *p;
    p = &a;

    printf("before: a = %d,  *p = %d\n", a, *p);
    a++;
    *p = *p + 100;
    printf("after: a = %d,  *p = %d\n", a, *p);

    printf("&a = %p, p = %p, sizeof(p) = %lld\n", &a, p, sizeof(p));
    printf("&p = %p", &p);

    return 0;
}
