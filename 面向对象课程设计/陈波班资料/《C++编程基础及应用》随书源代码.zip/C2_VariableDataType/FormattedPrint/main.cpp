//Project - FormattedPrint
#include <cstdio>
using namespace std;

int main(){
    int n = 3;
    float fPrice = 3.6, fMoney = 20;
    float fAmount = n*fPrice;
    fMoney = fMoney - fAmount;
    printf("%d apples, %.1f for each, %.2f in total.\n",n,fPrice,fAmount);
    printf("20 - %.2f = %.2f.",fAmount,fMoney);
    return 0;
}
