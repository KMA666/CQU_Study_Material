//Project - Trees
#include <iostream>
using namespace std;

int main(){
    int r = 8;       //类型为整数的变量r表示行数
    int c = 7;       //类型为整数的变量c表示列数
    int n = r * c;   //类型为整数的变量n表示梭梭树的总数
    cout << n;
    return 0;
}
