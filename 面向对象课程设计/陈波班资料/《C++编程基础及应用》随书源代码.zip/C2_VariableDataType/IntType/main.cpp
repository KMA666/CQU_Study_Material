//Project - IntType
#include <iostream>
using namespace std;

int main() {
    short si = 2194;
    cout << "short si = " << si << ", size = " << sizeof(si) << " bytes." << endl;

    int i {12};
    cout << "int i = " << i << ", size = " << sizeof(i) << " bytes." << endl;

    long li = 298289282;
    cout << "long li = " << li << ", size = " << sizeof(li) << " bytes." << endl;

    long long ll = 28929829982892;
    cout << "long long ll = " << ll << ", size = "
         << sizeof(long long) << " bytes." << endl;

    return 0;
}
