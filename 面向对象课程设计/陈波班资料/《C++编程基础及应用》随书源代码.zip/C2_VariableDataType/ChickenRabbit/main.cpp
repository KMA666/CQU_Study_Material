//Project - ChickenRabbit
#include <iostream>
using namespace std;

int main(){
    int iHeads = 35;            //头的数量
    int iFeet = 94;             //脚的数量
    int a = iFeet - 2 * iHeads; //假设全部是鸡，余下的脚的数量
    int iRabbits = a / 2;       //兔的数量等于余下的脚数/2
    int iChicken = iHeads - iRabbits; //鸡的数量等于 头的数量 - 兔的数量
    cout << "Number of chicken = " << iChicken
         << ", Number of rabbits = " << iRabbits << endl;

    if (iFeet == iChicken*2+iRabbits*4)  //验证脚数 = 鸡数*2 + 兔数*4
        cout << "The answer is right.";
    else
        cout << "The answer is wrong.";

    return 0;
}
