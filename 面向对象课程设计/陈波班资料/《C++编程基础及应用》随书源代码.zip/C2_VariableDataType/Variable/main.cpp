//Project - Variable
#include <iostream>
using namespace std;

int main(){
    int n = 3;
    float fPrice = 3.6;
    float fAmount = n*fPrice;
    float fMoney = 20;
    fMoney = fMoney - fAmount;
    cout << n << " apples," << fPrice << " for each,"
         << fAmount << " in total.\n";
    cout << "20 - " << fAmount << " = " << fMoney;
    return 0;
}
