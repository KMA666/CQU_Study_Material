//Project - FloatLiteral
#include <iostream>
using namespace std;

int main(){
    auto a = 3;            //int
    auto b {3.0};          //double
    auto c = 1.2E-5;       //double
    auto d = 1.2E+5L;      //long double
    auto e = -3.01e+12f;   //float

    cout << "Name:\ta\tb\tc\td\te\n";
    cout << "Type:\t" << typeid(a).name() << "\t" << typeid(b).name() << "\t"
         << typeid(c).name() << "\t" << typeid(d).name() << "\t" << typeid(e).name();

    return 0;
}
