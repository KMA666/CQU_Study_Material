//Project - HexOct
#include <iostream>
#include <cstdio>
using namespace std;

int main(){
    int b = 0x17;          //十六进制 hexadecimal
    int c = 017;           //八进制   octal
    int d = 0b01111110;    //二进制   binary

    cout << "0x17 = " << b << ", 017 = " << c << ", 0b01111110 = " << d << endl;
    printf("17: %x, %d, %o\n", 17, 17, 17);
    cout << "17: " << hex << 17 << ", " << dec << 17 << ", " << oct << 17 << endl;
    return 0;
}
