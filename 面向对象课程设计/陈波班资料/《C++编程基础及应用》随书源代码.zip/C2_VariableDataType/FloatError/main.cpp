//Project - FloatError
#include <iostream>
#include <cstdio>
using namespace std;

int main(){
    printf("sizeof(float) = %d, sizeof(double) = %d\n",
           sizeof(float),sizeof(double));

    float f = 0.00001;
    printf("The stored value of 0.00001 with float:   %.30f\n",f);

    double d = 0.00001;
    printf("The stored value of 0.00001 with double:   %.30f\n",d);

    f = f * 99000;
    if (f==0.99)
        printf("f*99000 == 0.99");
    else
        printf("f*99000 <> 0.99");

    return 0;
}
