//Project - DataType
#include <iostream>
using namespace std;

int main(){
    char c = 'z';
    cout << "char c = " << c << ", size = " << sizeof(char) << " bytes." << endl;

    short si = 2194;
    cout << "short si = " << si << ", size = " << sizeof(si) << " bytes." << endl;

    int i = int(12);
    cout << "int i = " << i << ", size = " << sizeof(i) << " bytes." << endl;

    long li = 298289282;
    cout << "long li = " << li << ", size = " << sizeof(li) << " bytes." << endl;

    long long ll = 28929829982892;
    cout << "long long ll = " << ll << ", size = "
         << sizeof(long long) << " bytes." << endl;

    bool b = 3 > 2;
    cout << "bool b = " << b << ", size = " << sizeof(bool) << " bytes." << endl;

    float f {79.23};
    cout << "float f = " << f << ", size = " << sizeof(float) << " bytes." << endl;

    double d {};
    cout << "double d = " << d << ", size = " << sizeof(d) << " bytes." << endl;

    return 0;
}
