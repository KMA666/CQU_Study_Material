//Project - SeqSearch
#include <iostream>
using namespace std;

int main() {
    const int N = 30;
    int h[N] = {175,161,162,169,147,170,170,152,171,155,
                157,166,157,158,160,161,161,163,164,165,
                173,175,165,166,166,168,168,147,169,170};

    int iSearchValue = 173;    //需要查找的值
    int iIndex = -1;           //结果下标, <0表示未找到
    for (int i=0;i<N;i++){
        if (h[i] == iSearchValue){
            iIndex = i;
            break;
        }
    }

    if (iIndex<0)
        cout << "Not found.";
    else
        cout << "h[" << iIndex << "] = " << iSearchValue;
    return 0;
}
