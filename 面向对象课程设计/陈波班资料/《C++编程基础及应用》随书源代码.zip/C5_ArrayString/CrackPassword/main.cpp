//Project - CrackPassword
#include <iostream>
#include <cstring>
using namespace std;

int main(){
    char sActualPass[8] = "secret";
    char sInputPass[8] = "";

    while (1){
        cout << "Enter your password:";
        cin >> sInputPass;
        if (strcmp(sInputPass,sActualPass)==0){
            cout << "Login sucessfully.\n";
            break;
        }
        else
            cout << "Wrong password.\n";
    }

    cout << "Start using the system...\n";
    return 0;
}
