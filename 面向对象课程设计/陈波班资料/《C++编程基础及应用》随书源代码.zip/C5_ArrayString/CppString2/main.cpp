//Project - CppString2
#include <iostream>
#include <string>
using namespace std;

int main() {
    string s = R"(I told you, "C/C++" is hard to learn, \n means a new line.)";
    cout << s << endl;

    string s1 = "I told you, \"C/C++\" is hard to learn, \\n means a new line.";
    cout << s1 << endl;
    return 0;
}
