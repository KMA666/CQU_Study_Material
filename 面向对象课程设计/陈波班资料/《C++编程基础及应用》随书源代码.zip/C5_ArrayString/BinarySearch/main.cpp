//Project - BinarySearch
#include <iostream>
using namespace std;

int binarySearch(const int a[], int left, int right, const int key){
    while (left<=right){
        int mid = (left+right)/2;
        if (a[mid]<key)
            left = mid + 1;
        else if (a[mid]>key)
            right = mid - 1;
        else
            return mid;  //在下标mid处找到key，返回mid
    }
    return -1;   //未找到，返回负数下标
}

int main() {
    const int N = 30;
    int h[N] = {145,147,147,152,155,157,157,158,160,161,
               161,161,162,163,164,165,165,166,166,166,
               168,168,169,169,170,170,170,171,173,175};
    int iSearchValue = 0;

    cout << "Input the number to search:";
    cin >> iSearchValue;
    int r = binarySearch(h,0,N-1,iSearchValue);

    if (r<0)
        cout << "Not found.";
    else
        cout << "h[" << r << "] = " << iSearchValue;
    return 0;
}
