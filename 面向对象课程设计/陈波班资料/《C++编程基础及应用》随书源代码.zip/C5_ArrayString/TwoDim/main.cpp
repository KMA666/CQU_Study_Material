//Project - TwoDim
#include <cstdio>

int main() {
    float scores[4][5] = {
        {67, 98, 77, 80, 86},
        {56, 89, 45, 76, 63},
        {78, 69, 96, 67, 99},
        {88, 19, 78, 55, 68}
    };
    scores[1][2] = 100;

    printf("scores = %p, sizeof(scores) = %lld\n",scores, sizeof(scores));
    printf("scores[0~3] = %p %p %p %p\n",scores[0],scores[1],scores[2],scores[3]);
    printf("&scores[1][0~2] = %p %p %p\n",&scores[1][0],&scores[1][1],&scores[1][2]);
    printf("&scores[1~2][1] = %p %p\n",&scores[1][1], &scores[2][1]);

    float fSum = 0;
    for (unsigned int j=0;j<5;j++)
        fSum += scores[1][j];
    float fAverage = fSum / 5;
    printf("Average of scores[1][0~4] = %.2f",fAverage);

    return 0;
}
