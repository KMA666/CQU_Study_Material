//Project - Subscript
#include <cstdio>

int main() {
    int a1[5] = {11,11,11,11,11};
    int a2[5] = {0,1,2,3,4};
    int a3[5] = {33,33,33,33,33};

    printf("%p - %p - %p\n",a1,a2,a3);
    printf("%d,%d,%d,%d,%d\n",a2[0],a2[1],a2[2],a2[3],a2[4]);
    printf("a2[-4] = %d\n",a2[-4]);
    printf("a2[8] = %d\n",a2[8]);

    return 0;
}
