//Project - MulMatrix
#include <iostream>
#include <iomanip>

bool multiMatrix(const int a[], int aRow, int aCol,
                 const int b[], int bRow, int bCol,
                 int c[], int cRow, int cCol){
    if ((aCol!=bRow) || (aRow!=cRow) || (bCol!=cCol)
        || (aRow<=0) || (bRow<=0) || (bCol<=0))
        return false;

    for (int i=0;i<cRow;i++)
        for (int j=0;j<cCol;j++){
            c[i*cCol+j] = 0;
            for (int k=0;k<aCol;k++)
                c[i*cCol+j] += a[i*aCol+k] * b[k*bCol+j];
        }
    return  true;
}

int main(){
    using namespace std;
    int a[] = { 5,7,4,3,6,1 };
    int b[] = { -3,2,4,4,1,11 };
    int c[9];
    if (!multiMatrix(a,3,2,b,2,3,c,3,3)){
        cout << "Illegal parameters for matrix multiply.";
        return 0;
    }

    for (int i=0;i<3;i++){
        for (int j=0;j<3;j++)
            cout << setw(5) << c[i*3+j]; //set(w)设置输出宽度为5个字符
        cout << "\n";
    }
    return 0;
}
