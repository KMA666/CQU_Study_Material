//Project - BitXor2
#include <iostream>
#include <bitset>
using namespace std;

int main(){
    unsigned char a = 0xaa;
    unsigned char b = 0xf0;
    cout << "a   = " << bitset<8>(a) << endl;
    cout << "b   = " << bitset<8>(b) << endl;
    cout << "a^b = " << bitset<8>(a^b) << endl;
    return 0;
}
