//Project - BitAnd
#include <iostream>
#include <bitset>
using namespace std;

int main() {
    unsigned int a = 0x8ffff37a;
    unsigned int b = 0xfc7779f6;

    unsigned int c = a & b;
    cout << "a     = " << bitset<32>(a) << endl;
    cout << "b     = " << bitset<32>(b) << endl;
    cout << "a & b = " << bitset<32>(c) << endl;

    cout << "a            = " << bitset<32>(a) << endl;
    cout << "0xfffffff7   = " << bitset<32>(0xfffffff7) << endl;
    a &= 0xfffffff7;      //复合操作符，等价于a = a & 0xfffffff7;
    cout << "a & fffffff7 = " << bitset<32>(a) << endl;

    return 0;
}
