//Project - LeftShift
#include <iostream>
#include <bitset>
using namespace std;

int main() {
    unsigned short a = 5;
    cout << "a      = " << bitset<16>(a) << ", value = " << a <<endl;
    a = a << 3;    //等价于 a <<= 3;
    cout << "a << 3 = " << bitset<16>(a) << ", value = " << a << endl;
    return 0;
}
