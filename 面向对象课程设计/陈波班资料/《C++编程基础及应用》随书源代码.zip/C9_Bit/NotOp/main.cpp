//Project - NotOp
#include <iostream>
#include <bitset>
using namespace std;

int main(){
    unsigned char c = 0b01011101;
    //二进制字面量是C++14引入的，早期版本中请用0x5d代替
    unsigned char d = ~c;
    cout << "c  = " << bitset<8>(c) << endl;
    //尖括号中的8是模板参数，意即要把c转为8位二进制字符串
    cout << "~c = " << bitset<8>(d) << endl;

    return 0;
}
