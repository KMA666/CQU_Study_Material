//Project - SetResetBit
#include <iostream>
#include <bitset>
using namespace std;

template <typename T>
inline void setBit(T& v,  int bit){
    v |= (0x01 << bit);
}

template <typename T>
inline void resetBit(T&v, int bit){
    v &= (~(0x01 << bit));
}

int main() {
    unsigned short v = 0xff00;
    cout << "before v = " << bitset<16>(v) << endl;

    setBit(v,6);
    setBit(v,0);
    setBit(v,11);    //置0，6，11位为1
    resetBit(v,15);
    resetBit(v,10);  //置10，15位为0

    cout << "after  v = " << bitset<16>(v) << endl;
    return 0;
}
