//Project - SharedPointer
#include <iostream>
#include <memory>
using namespace std;

class Fish {
public:
    string sName;
    Fish(const string& name){
        sName = name;
        cout << "Fish Constructor called: " << sName << endl;
    }

    void sayHello(){
        cout << "Aloha: " << sName << endl;
    }

    ~Fish(){
        cout << "Fish Destructor called:  "  << sName << endl;
    }
};

void sayHello(shared_ptr<Fish> f){
    f->sayHello();      //对智能指针使用指向操作符->
}

void sayHello(Fish& f){
    f.sayHello();
}

int main(){
    shared_ptr<Fish> dora1(new Fish("Dora"));
    shared_ptr<Fish> tom1 = make_shared<Fish>("Tom");
    cout << "-----------------------------------------" << endl;

    sayHello(tom1);
    auto tom2 = tom1;   //智能指针对象的复制
    sayHello(*tom2);    //对智能指针使用解引用操作符*
    cout << "-----------------------------------------" << endl;

    dora1->sayHello();
    Fish* dora2 = dora1.get();   //获取智能指针内的原始指针
    dora2->sayHello();
    cout << "-----------------------------------------" << endl;
    return 0;
}
