//Project - UserStringDeepCopy
#include <iostream>
#include <string.h>
using namespace std;

class UserString {
private:
    char* buffer = nullptr;       //缓冲区指针
    unsigned long long size = 0;  //缓冲区大小

public:
    const UserString& operator=(const char* s){
        unsigned long long sizeNeeded = strlen(s) + 1;
        if (size >= sizeNeeded)   //缓冲区够用，直接复制
            strcpy(buffer,s);
        else {
            if (buffer!=nullptr)  //缓冲区不够用，重新申请后再复制
                free(buffer);
            size = sizeNeeded;
            buffer = (char*)calloc(size,1);
            strcpy(buffer,s);
        }
        return *this;
    }

    const UserString& operator=(const UserString& r){
        if (buffer!=nullptr)
            free(buffer);
        size = r.size;
        if (size>0 && r.buffer!=nullptr){
            buffer = (char*)calloc(size,1);
            strcpy(buffer,r.buffer);
        }
        return *this;
    }

    ~UserString(){
        if (buffer!=nullptr)
            free(buffer);       //释放缓冲区,现在安全了
    }

    UserString(const UserString& r){
        size = r.size;
        if (size>0 && r.buffer!=nullptr){
            buffer = (char*)calloc(size,1);
            strcpy(buffer,r.buffer);
        }
    }

    UserString(){}             //不可或缺
    friend ostream& operator<<(ostream&, const UserString&);
};

ostream& operator<<(ostream& o, const UserString& r){
    o << r.buffer;
    return o;
}

int main() {
    UserString s1,s2;
    s1 = "New coronavirus believed to be derived from bats.";
    s2 = s1;                  //operator=操作符函数
    s2 = "Human beings will win!";
    cout << "s1 = " << s1 << endl;
    cout << "s2 = " << s2 << endl;
    return 0;
}
