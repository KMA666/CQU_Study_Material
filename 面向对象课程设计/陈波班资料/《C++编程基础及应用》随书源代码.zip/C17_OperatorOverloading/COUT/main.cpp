//Project - COUT
#include <iostream>
using namespace std;

int main() {
    cout << "pi = " << 3.14159 << endl;
    operator<<(cout,"pi = ").operator<<(3.14159).operator<<(endl);
    return 0;
}
