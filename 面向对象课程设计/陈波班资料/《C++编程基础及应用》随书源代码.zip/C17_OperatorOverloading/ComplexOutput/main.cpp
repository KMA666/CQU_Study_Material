//Project - ComplexOutput
#include <iostream>
using namespace std;

class Complex {
public:
    double dReal;
    double dImage;

    Complex(double real, double image){
        dReal = real; dImage = image;
    }
};

ostream& operator<<(ostream& o, const Complex& c){
    o << c.dReal << " + " << c.dImage << "i";
    return o;
}

int main() {
    Complex a(1,3);
    cout << a << endl;
    operator<<(cout,a).operator<<(endl);
    return 0;
}
