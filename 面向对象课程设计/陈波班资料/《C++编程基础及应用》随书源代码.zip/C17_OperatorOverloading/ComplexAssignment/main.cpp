//Project - ComplexAssignment
#include <iostream>
using namespace std;

class Complex {
public:
    double dReal;
    double dImage;

    Complex(double real, double image){
        dReal = real; dImage = image;
    }

    const Complex& operator=(const Complex& r){
        cout << "Complex::operator=()" << endl;
        dReal = r.dReal;  dImage = r.dImage;
        return *this;
    }
};

int main() {
    Complex a(1,3), b(2,3), c(1,5);
    c = b = a;
    c.operator=(b.operator=(a));
    return 0;
}
