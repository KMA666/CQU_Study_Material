//Project - SharedPtrArray
#include <iostream>
#include <memory>
using namespace std;

template <typename T>
void delete_array(T* p){
    cout << "delete_array" << endl;
    delete[] p;
}

class Fish{
public:
    ~Fish(){ cout << "Fish::Fish~()" << endl; }
};

int main(){
    shared_ptr<Fish[]> a(new Fish[4]);
    a = nullptr;   //a指针指向的数组被释放

    shared_ptr<Fish> b(new Fish[2],delete_array<Fish>);
    b.reset();     //b指针指向的数组被释放

    shared_ptr<float> c(new float[512],
        [](float*p){cout << "lambda function\n"; delete[] p;});
    *c = 4.4F;
    //c++;           //错误：智能指针不支持指针运算
    //c[1] = 99.2F;  //错误：智能指针不支持[]操作符
    cout << *c << endl;
    return 0;
}
