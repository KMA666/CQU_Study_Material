//Project - ComplexDoublePlus
#include <iostream>
using namespace std;

class Complex {
public:
    double dReal;
    double dImage;

    Complex(double real, double image){
        dReal = real; dImage = image;
    }

    const Complex& operator++(){    //对应++c，先++，后取值
        dReal += 1.0;
        return *this;
    }

    const Complex operator++(int){  //对应c++，先取值，后++
        Complex t = *this;
        dReal += 1.0;
        return t;
    }
};

ostream& operator<<(ostream& o, const Complex& c){
    o << c.dReal << " + " << c.dImage << "i";
    return o;
}

int main() {
    Complex c(1,3);
    cout << c << " --> " << ++c << endl;   //先++,后取值
    cout << c++ << " --> " << c << endl;   //先取值，后++
    return 0;
}
