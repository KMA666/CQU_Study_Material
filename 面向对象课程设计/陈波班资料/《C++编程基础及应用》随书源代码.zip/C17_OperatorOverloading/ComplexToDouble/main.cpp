//Project - ComplexToDouble
#include <iostream>
#include <math.h>
using namespace std;

class Complex {
public:
    double dReal;
    double dImage;

    Complex(double real, double image){
        dReal = real; dImage = image;
    }

    operator double(){
        cout << "operator double()" << endl;
        return sqrt(dReal*dReal + dImage*dImage);  //返回复数的模
    }
};

int main() {
    Complex c(1,5);
    double r = 3 + c; //3 + c等价于3 + c.operator double()
    cout << r << endl;
}
