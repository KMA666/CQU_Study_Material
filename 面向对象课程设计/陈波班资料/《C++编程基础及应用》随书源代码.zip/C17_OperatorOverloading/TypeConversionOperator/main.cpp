//Project - TypeConversionOperator
#include <iostream>
#include <string.h>
using namespace std;

class UserString {
private:
    char* buffer = nullptr;       //缓冲区指针
    unsigned long long size = 0;  //缓冲区大小

public:
    const UserString& operator=(const char* s){
        unsigned long long sizeNeeded = strlen(s) + 1;
        if (size >= sizeNeeded)   //缓冲区够用，直接复制
            strcpy(buffer,s);
        else {
            if (buffer!=nullptr)  //缓冲区不够用，重新申请后再复制
                free(buffer);
            size = sizeNeeded;
            buffer = (char*)calloc(size,1);
            strcpy(buffer,s);
        }
        return *this;
    }

    ~UserString(){
        if (buffer!=nullptr)
            free(buffer);
    }

    //将对象转换成char*的操作符函数
    operator char*(){
        return buffer;
    }
};

int main() {
    UserString s;
    s = "Aloha";
    cout << s << endl;
    cout << s.operator char *() << endl;
    return 0;
}
