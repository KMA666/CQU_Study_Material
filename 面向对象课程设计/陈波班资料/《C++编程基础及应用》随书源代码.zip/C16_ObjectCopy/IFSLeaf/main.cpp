//Project - IFSLeaf
#include <iostream>
#include <array>
#include <algorithm>
#include <QImage>
#include <QDir>
using namespace std;

void ifs(vector<double>& xs,
         vector<double>& ys,
         vector<uint8_t>& cs, const int N)
{
    xs.resize(N); ys.resize(N); cs.resize(N);
    double x = 0, y = 0;
    for (unsigned int i=0;i<N;i++){
        double r = rand()/double(RAND_MAX);
        double x1 = 0, y1 = 0;
        if (r<=0.01){
            x1 = 0;
            y1 = 0.15*y;
            cs[i] = 0;
        }
        else if (r<=0.08){
            x1 = 0.21*x - 0.19*y;
            y1 = 0.24*x + 0.27*y + 1.5;
            cs[i] = 1;
        }
        else if (r<=0.15){
            x1 = -0.14*x + 0.26*y;
            y1 = 0.26*x + 0.25*y + 0.47;
            cs[i] = 2;
        }
        else{
            x1 = 0.87*x;
            y1 = -0.05*x + 0.84*y + 1.54;
            cs[i] = 3;
        }
        x = x1;  y = y1;
        xs[i] = x; ys[i] = y;
    }
}

QString saveJpg(const vector<double>& xs,
                const vector<double>& ys,
                const vector<uint8_t>& cs)
{
    double xMax = *max_element(xs.cbegin(),xs.cend());
    double xMin = *min_element(xs.cbegin(),xs.cend());
    double yMax = *max_element(ys.cbegin(),ys.cend());
    double yMin = *min_element(ys.cbegin(),ys.cend());

    int w = (xMax-xMin)*100;
    int h = (yMax-yMin)*100;

    QImage img(w,h,QImage::Format_RGB32);
    img.fill(QColor(255,255,255));
    for (auto i=0;i<xs.size();i++){
        int x = w*(xs[i]-xMin)/(xMax-xMin);
        int y = h-h*(ys[i]-yMin)/(yMax-yMin);
        auto c = cs[i];
        auto clr = c==0?Qt::black:(c==1?Qt::red:(c==2?Qt::blue:Qt::green));
        img.setPixelColor(x,y,clr);
    }

    QString sFile = QDir::currentPath() + "\\ifs.jpg";
    img.save(sFile);
    return sFile;
}

int main()
{
    const int N = 100000;
    vector<double> xs, ys;
    vector<uint8_t> cs;
    ifs(xs,ys,cs,N);
    auto sFile = saveJpg(xs,ys,cs);
    cout << "File saved: "<< sFile.toStdString();
    return 0;
}
