//Project - DeepCopy
#include <iostream>
#include <string.h>
using namespace std;

class UserString {
private:
    char* buffer = nullptr;       //缓冲区指针
    unsigned long long size = 0;  //缓冲区大小

public:
    void assign(const char* s){
        unsigned long long sizeNeeded = strlen(s) + 1;
        if (size >= sizeNeeded)   //缓冲区够用，直接复制
            strcpy(buffer,s);
        else {
            if (buffer!=nullptr)  //缓冲区不够用，重新申请后再复制
                free(buffer);
            size = sizeNeeded;
            buffer = (char*)calloc(size,1);
            strcpy(buffer,s);
        }
    }

    const char* content(){
        return buffer;           //返回字符数组的地址
    }

    ~UserString(){
        if (buffer!=nullptr)
            free(buffer);       //释放缓冲区,危险！
    }

    UserString(const UserString& r){
        size = r.size;
        if (size>0 && r.buffer!=nullptr){
            buffer = (char*)calloc(size,1);
            strcpy(buffer,r.buffer);
        }
    }

    //自定义拷贝构造函数导致编译器放弃为类型准备公有的默认构造函数
    UserString(){}             //不可或缺
};

int main() {
    UserString s1;
    s1.assign("New coronavirus believed to be derived from bats.");

    UserString s2 = s1;      //默认拷贝构造
    s2.assign("Human beings will win!");

    cout << "s1 = " << s1.content() << endl;
    cout << "s2 = " << s2.content() << endl;
    return 0;
}
