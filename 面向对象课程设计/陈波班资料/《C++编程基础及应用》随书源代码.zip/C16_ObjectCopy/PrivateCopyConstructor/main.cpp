//Project - PrivateCopyConstructor
#include <iostream>
using namespace std;

class UserString{
public:
    //...
    UserString(){}
private:
    UserString(const UserString& r){}
};

void output(const UserString& s){
    //...
    return;
}

int main(){
    UserString s1;
    //UserString s2 = s1; //错误：不可以调用私有的拷贝构造函数
    UserString& s2 = s1;

    output(s1);           //传引用，不导致拷贝构造
    return 0;
}
