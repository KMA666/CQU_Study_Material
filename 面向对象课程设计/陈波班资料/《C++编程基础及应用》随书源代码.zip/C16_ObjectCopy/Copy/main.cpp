//Project - Copy
#include <iostream>
using namespace std;

class Circle{
public:
    int x = 0;
    int y = 0;
    float fRadius = 3.2F;
    Circle() {
        cout << "Circle::Circle()" << endl;
    }

    ~Circle() {
        cout << "Circle::~Circle()" << endl;
    }
};

void drawCircle(Circle x){
    printf("drawCircle: (%d,%d), r = %f\n", x.x,x.y,x.fRadius);
}

int main() {
    Circle c1;
    Circle c2(c1);
    Circle c3 = c1;

    cout << "--------------------------------------------------\n";
    drawCircle(c1);
    cout << "--------------------------------------------------\n";

    return 0;
}
