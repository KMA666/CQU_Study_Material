//Project - FriendMemberFunction
#include <iostream>
using namespace std;

class Complex;

class Computer{         //计算器类
public:
    void output(const Complex& c);
};

class Complex{          //复数类
private:
    float fReal;        //私有的实部和虚部
    float fImage;
public:
    Complex(float real, float img){
        fReal = real;
        fImage = img;
    }                   //友元成员函数
    friend void Computer::output(const Complex&);
};

void Computer::output(const Complex& c){
    cout << "Complex(" << c.fReal << " + "
         << c.fImage << "i)" << endl;
}

int main() {
    Complex a(3,2);

    Computer c;
    c.output(a);
    return 0;
}
