//Project - ConstMemberFunction
#include <iostream>
#include <math.h>
using namespace std;

class Complex {
private:
    float fReal;
    float fImage;
    mutable bool bAbsComputed = false;
public:
    Complex(float real, float image){
        fReal = real;
        fImage = image;
    }

    const Complex& add(const Complex& v){
        fReal += v.fReal;
        fImage += v.fImage;
        return *this;
    }

    float abs() const {
        bAbsComputed = true;  //正确：可以修改mutable类型的数据成员
        //fReal += 10;        //错误：不可以修改非mutable类型的数据成员
        //add(Complex(1,2));  //错误：不可以调用非const类型的成员函数
        return sqrt(fReal*fReal + fImage*fImage);
    }
};

int main() {
    Complex c(2,3);
    c.add(Complex(1,1));

    const Complex* p = &c;
    const Complex& r = c;
    //p->add(Complex(1,1));  //错误：不可以执行常量型对象的非常量型成员函数
    //r.add(Complex(1,1));   //错误：不可以执行常量型对象的非常量型成员函数

    cout << "abs(r) = " << r.abs() << endl;
    return 0;
}
