//Project - HeaderCpp
#include <iostream>
#include <person.h>
using namespace std;

int main() {
    Person dora;
    dora.sID = "3604020001"; //访问公有数据成员
    dora.sName = "Dora Henry";
    dora.setIncome(5000);    //访问公有成员函数
    cout << dora.description();
    return 0;
}
