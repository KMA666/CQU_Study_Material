#ifndef PERSON_H
#define PERSON_H

#include <string>
using namespace std;

class Person{
private:                         //可略去不写，默认为private
    float fIncome {0.0f};        //月收入
    float computeIncomeTax(){    //计算收入税 - 内联成员函数
        return fIncome*0.2F;     //收入税=月收入 x 20%
    }
public:
    string sID;
    string sName;

    void setIncome(float fIncome); //设置月收入
    string description();
};

#endif // PERSON_H
