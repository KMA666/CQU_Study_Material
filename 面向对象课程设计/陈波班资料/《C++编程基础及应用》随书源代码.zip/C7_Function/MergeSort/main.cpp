//Project - MergeSort
#include <cstdio>
#include <cstdlib>

void merge(int a[],int low, int mid, int high) {
    int* t = (int*)malloc((high-low+1)*sizeof(int));
    int i = low, j = mid+1, k = 0;
    while (i<=mid && j<=high){
        if (a[i]<=a[j])
            t[k++] = a[i++];
        else
            t[k++] = a[j++];
    }
    while (i<=mid)
        t[k++] = a[i++];
    while (j<=high)
        t[k++] = a[j++];
    for (i=low,k=0;i<=high;i++,k++)
        a[i] = t[k];
    free(t);
}

void mergeSort(int a[], int low, int high) {
    if (low<high){
        int mid = (low+high)/2;
        mergeSort(a,low,mid);
        mergeSort(a,mid+1,high);
        merge(a,low,mid,high);
    }
}

int main() {
    int v[8] = {8,4,2,9,5,3,1,7};
    mergeSort(v,0,7);
    printf("Sorted: ");
    for (int i=0;i<8;i++)
        printf("%d ",v[i]);
    return 0;
}
