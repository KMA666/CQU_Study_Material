//Project - Abstract
#include <iostream>
using namespace std;

//本程序是伪代码，无法运行

int main() {

    while (true) {
        auto cmd = fectchCommandFromQueque();
        if (cmd){
            auto resp = executeCommand(cmd);
            sendResponse(resp);
        }
        else
            sleep(0.01);
        readAndParseCommands();
    }

    return 0;
}
