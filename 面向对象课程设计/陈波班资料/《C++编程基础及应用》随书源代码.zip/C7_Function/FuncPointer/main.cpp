//Project - FuncPointer
#include <cstdio>

int add(int a, short b){
    return a + b;
}

int main() {
    float f = 3.3F;
    int c = 33;
    printf("add = %p,  &f = %p, &c = %p\n", add, &f, &c);

    int (*pf)(int, short) = NULL;
    pf = add;
    printf("pf = %p,  &pf = %p\n", pf, &pf);

    int d = pf(3,2);
    printf("3+2 = %d", d);

    return 0;
}
