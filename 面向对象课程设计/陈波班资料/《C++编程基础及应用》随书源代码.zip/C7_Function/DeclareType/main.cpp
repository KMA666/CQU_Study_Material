//Project - DeclareType
#include <iostream>
using namespace std;

template <typename T1, typename T2>
auto add(T1& a, T2& b) // -> decltype(a+b)在C++ 17中不再被需要
{
    auto c = a + b;
    return c;
}

int main() {
    int a = 1;
    float b = 1.1F;

    auto c = add(a,b);
    auto d = add<float,int>(b,a);
    cout << "c = " << c << ", type = " << typeid(c).name() << endl;
    cout << "d = " << d << ", type = " << typeid(d).name() << endl;

    return 0;
}
