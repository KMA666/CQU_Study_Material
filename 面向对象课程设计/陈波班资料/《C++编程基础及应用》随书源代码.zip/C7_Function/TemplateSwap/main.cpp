//Project - TemplateSwap
#include <iostream>
using namespace std;

template <typename T>
void swapObject(T& a, T& b){
    auto t = a;
    a = b;
    b = t;
}

int main() {
    char c1 {'a'}, c2 {'z'};
    swapObject(c1,c2);
    cout << "c1 = " << c1 << ", c2 = " << c2 << endl;

    double d1{1.1}, d2{9.9};
    swapObject(d1,d2);
    cout << "d1 = " << d1 << ", d2 = " << d2 << endl;

    short s1{-22}, s2{22};
    swapObject<short>(s1,s2);
    cout << "s1 = " << s1 << ", s2 = " << s2 << endl;

    return 0;
}
