//File -- add.cpp
float add(float a, float b){ return a + b; }
double add(double a, double b){ return a + b; }