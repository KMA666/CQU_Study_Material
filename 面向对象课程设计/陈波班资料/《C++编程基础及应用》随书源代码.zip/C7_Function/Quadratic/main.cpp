//Project - Quadratic
#include <cstdio>

float f(float);					//函数的声明(declaration)或者原型(prototype)

int main(){
    printf("f(0) = %f,  f(2) = %f,  f(-4) = %f", f(0),f(2),f(-4));
    return 0;
}

float f(float x){			   //函数的定义(definition)
    float y = x*x + 3*x + 1;
    return y;
}
