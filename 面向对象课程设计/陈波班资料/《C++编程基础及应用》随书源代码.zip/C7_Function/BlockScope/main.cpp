//Project - BlockScope
#include <cstdio>

int main(int argc, char **argv){
    int a = 5;
    int b = 6;

    {
        int a = 9;
        int c = 10;

        printf("a = %d, &a = %p\n", a, &a);     //第9行的内层a
        printf("b = %d, &b = %p\n", b, &b);     //第6行的外层b
        printf("c = %d, &c = %p\n", c, &c);     //第10行的内层c
    }

    printf("a = %d, &a = %p\n", a, &a);         //第5行的外层a
    //b = c;                                    //错误：b可见，但c不可见
    printf("b = %d, &b = %p\n", b, &b);         //第6行的外层b
    printf("argc = %d", argc);                  //main()函数的形参
    return 0;
}
