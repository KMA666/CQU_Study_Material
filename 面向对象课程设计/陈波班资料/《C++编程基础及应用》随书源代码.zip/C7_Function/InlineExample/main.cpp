//Project - InlineExample
#include <iostream>
#include <bitset>
using namespace std;

//将无符号整数v的第bit位设置为1
inline void setBit(unsigned int& v,  int bit){
    v |= (0x01 << bit);
}

int main() {
    unsigned int v = 0x00000000;
    cout << "before setBit: " << bitset<32>(v) << endl;

    setBit(v,0);
    setBit(v,31);
    v |= (0x01 << 11);

    cout << "after setBit:  " << bitset<32>(v) << endl;
    return 0;
}

