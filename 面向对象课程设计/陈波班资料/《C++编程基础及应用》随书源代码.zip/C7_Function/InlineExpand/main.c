//Project - InlineExpand
#include <stdio.h>

int main() {
    float values[] = {0,1,2,3,4,5,6,7,8,9};

    float v4;
    {
        float* a = values;
        int n = 4;
        float fSum = 0;
        for (int i=0;i<n;i++)
            fSum += a[i];
        v4 = fSum / n;
    }
    printf("v4 = %f\n",v4);

    float v7;
    {
        float* a = values;
        int n = 7;
        float fSum = 0;
        for (int i=0;i<n;i++)
            fSum += a[i];
        v7 = fSum / n;
    }
    printf("v7 = %f\n",v7);

    float v10;
    {
        float* a = values;
        int n = 10;
        float fSum = 0;
        for (int i=0;i<n;i++)
            fSum += a[i];
        v10 = fSum / n;
    }
    printf("v10 = %f\n",v10);

    return 0;
}
