//Project - FuncOverloading1
#include <iostream>
using namespace std;

void swapObject(float& a, float& b){
    cout << "swapObject_float,a=" << a << ",b=" << b << endl;
    auto t = a;
    a = b;
    b = t;
}

void swapObject(double& a, double& b){
    cout << "swapObject_double,a=" << a << ",b=" << b << endl;
    auto t = a;
    a = b;
    b = t;
}

int main() {
    double d1 {1.1}, d2{9.9};
    swapObject(d1,d2);
    cout << "d1 = " << d1 << ", d2 = " << d2 << endl;

    float f1 {2.2}, f2 {8.8};
    swapObject(f1,f2);
    cout << "f1 = " << f1 << ", f2 = " << f2 << endl;

    return 0;
}
