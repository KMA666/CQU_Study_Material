//Project - Fib
#include <iostream>
#include <iomanip>
using namespace std;

long long fib(int n){
    if (n<=2)
        return 1;
    long long a = 1, b = 1;  //最近两项的值，a为前前项，b为前项
    long long v = 0;
    for (auto i=3;i<=n;i++){
        v = a + b;           //当前项 = 前前项 + 前项
        a = b;  b = v;       //前前项 = 前项, 前项 = 当前项
    }
    return v;
}

int main() {
    cout << setw(4)  << left << "x"
         << setw(6) << right << "x^2"
         << setw(10) << right << "x^3"
         << setw(20) << right << "fib(x)" << endl;
    cout << "-----------------------------------------" << endl;
    for (auto i=0; i<=5; i++){
        int x = i==0?1:12*i;
        cout << setw(4)  << left << x << setfill(' ');
        cout << setw(6) << right << x*x;
        cout << setw(10) << right << x*x*x;
        cout << setw(20) << right << fib(x) << endl;
    }
    return 0;
}
