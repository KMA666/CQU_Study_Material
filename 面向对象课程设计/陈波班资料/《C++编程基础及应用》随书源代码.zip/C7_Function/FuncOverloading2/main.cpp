//Project - FuncOverloading2
#include <iostream>
using namespace std;

int  f1(int a,   float b, char c);
int  f1(float a, int b,   char c);
char f1(char a,  int b);
//void f1(int a, float b, char c); //错误：函数名重载不能依赖于返回值类型

int main(){
    cout << "Hello World!" << endl;
    return 0;
}
