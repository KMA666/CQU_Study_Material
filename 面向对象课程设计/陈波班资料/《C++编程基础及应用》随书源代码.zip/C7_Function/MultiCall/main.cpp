//Project - MultiCall
#include <iostream>
using namespace std;

inline float average(float* a, int n) {
    float fSum = 0;
    for (int i=0;i<n;i++)
        fSum += a[i];
    return fSum/n;
}

int main() {
    float values[] = {0,1,2,3,4,5,6,7,8,9};

    float v4 = average(values,4);
    cout << "v4 = " << v4 << endl;

    float v7 = average(values,7);
    cout << "v7 = " << v7 << endl;

    float v10 = average(values,10);
    cout << "v10 = " << v10 << endl;

    return 0;
}
