//Project - TextAndBinaryCpp
#include <iostream>
#include <fstream>
#include <iomanip>
#include <unistd.h>
using namespace std;

int main(){
    char sPath[1024];
    getcwd(sPath,1024);
    cout << "cwd: " << sPath << endl;

    float fPi = 3.1415927f;

    ofstream fText("pi.txt");
    fText << fixed << setprecision(7) << fPi;
    fText.close();

    fstream fBin;
    fBin.open("pi.dat",ios::binary|ios::out);
    fBin.write(reinterpret_cast<const char*>(&fPi),sizeof(float));
    fBin.close();

    fPi = 0.0f;
    fBin.open("pi.dat",ios::binary|ios::in);
    fBin.read(reinterpret_cast<char*>(&fPi),sizeof(float));
    fBin.close();
    cout << fixed << setprecision(7) << fPi << endl;

    return 0;
}
