//Project - ReadSquareTable
#include <stdio.h>

int main(){
    FILE *fp = NULL;
    char sFile[] = "D:/C2Cpp/C20_FileIO/build-CreateSquareTable-Desktop_Qt_5_14_1_MinGW_64_bit-Debug/SquareTable.txt";
    if ((fp=fopen(sFile,"rt"))==NULL){
        printf("File open error - SquareTable.txt.\n");
        return -1;               //返回非零值表示程序出错
    }

    char sBuffer[512];
    if (fgets(sBuffer,512,fp))
        printf("%s",sBuffer);
    if (fgets(sBuffer,512,fp))
        printf("%s",sBuffer);

    int n=0, n2=0;
    while (1){
        if (fscanf(fp,"%d %d",&n,&n2)>0)
            printf("%6d%14d\n",n,n2);
        else
            break;
    }

    if (fclose(fp)!=0){
        printf("File close error - SquareTable.txt.\n");
        return -1;
    }

    return 0;
}
