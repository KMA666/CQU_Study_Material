//Project - CreateSquareTable
#include <stdio.h>
#include <unistd.h>

int main(){
    char sPath[512];
    if (getcwd(sPath,512)!=NULL) //获取并打印当前工作路径
        printf("Current working directory: %s\n",sPath);

    FILE *fp = NULL;
    if ((fp=fopen("SquareTable.txt","wt"))==NULL){
        printf("File open error - SquareTable.txt.\n");
        return -1;               //返回非零值表示程序出错
    }

    fprintf(fp,"%6s%14s\n","N","N^2");
    fputs("--------------------\n",fp);
    for (int n=1;n<=20;n++){
        fprintf(fp,"%6d%14d\n",n,n*n);
    }

    if (fclose(fp)!=0){
        printf("File close error - SquareTable.txt.\n");
        return -1;
    }

    printf("File created & writed successfully: %s/SquareTable.txt",sPath);
    return 0;
}
