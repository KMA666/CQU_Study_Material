//Project - BinaryPriceList
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <fcntl.h>

typedef struct {
    int iNo;            //商品编号，不重复
    char sName[20];     //名称
    float fPrice;       //价格
    int iQuantity;      //在库数量
} Commodity;

bool locateCommodity(FILE* f, int iNo){
    rewind(f);          //读写指针回到文件头
    int t;
    while (true){
        if (fread(&t,sizeof(int),1,f)!=1)
            return false;
        if (t==iNo){
            fseek(f,-sizeof(int),SEEK_CUR);
            return true;
        }
        else
            fseek(f,sizeof(int)+sizeof(float)+20,SEEK_CUR);
    }
}

void saveCommodity(FILE* f, const Commodity* c){
    if (!locateCommodity(f,c->iNo))
        fseek(f,0,SEEK_END);

    fwrite(&c->iNo,sizeof(int),1,f);
    fwrite(c->sName,20,1,f);
    fwrite(&c->fPrice,sizeof(float),1,f);
    fwrite(&c->iQuantity,sizeof(int),1,f);
}

bool loadCommodity(FILE* f, int iNo, Commodity* c){
    if (!locateCommodity(f,iNo))
        return false;

    fread(&c->iNo,sizeof(int),1,f);
    fread(c->sName,20,1,f);
    fread(&c->fPrice,sizeof(float),1,f);
    fread(&c->iQuantity,sizeof(int),1,f);
    return true;
}

int main() {
    char sPath[512];
    if (getcwd(sPath,512)!=NULL)              //获取并打印当前工作路径
        printf("cwd: %s\n",sPath);

    FILE* f = NULL;
    if (access("commodity.dat",F_OK)==0)     //判断文件是否存在
        f = fopen("commodity.dat","rb+");     //打开已有文件进行随机读写
    else
        f = fopen("commodity.dat","wb+");     //打开新文件进行随机读写

    Commodity c1 = {1,"Apple",5.2764123f,2000};
    saveCommodity(f,&c1);

    printf("ftell(f): %ld\n",ftell(f));      //输出文件当前读写位置

    Commodity c3 = {3,"Beef",65.741f,5000};
    saveCommodity(f,&c3);
    Commodity c5 = {5,"Cherry",117.4f,500};
    saveCommodity(f,&c5);
    strcpy(c3.sName,"Pork");
    saveCommodity(f,&c3);

    Commodity t;
    printf("%-6s%-20s%10s%10s\n","No","Name","Price","Quantity");
    printf("----------------------------------------------\n");
    for (int i=1;i<=5;i++){
        if (!loadCommodity(f,i,&t))
            printf("%-6d%-20s%10.2f%10d\n",i,"NA",0.0,0);
        else
            printf("%-6d%-20s%10.2f%10d\n",t.iNo,t.sName,t.fPrice,t.iQuantity);
    }

    fclose(f);
    return 0;
}
