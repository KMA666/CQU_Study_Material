//Project - CreatePriceList
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <unistd.h>
#include <assert.h>
using namespace std;

class Commodity{
    string sNo;       //产品编号
    string sName;     //产品名称
    float fPrice;     //价格
    int iQuantity;    //库存数量
public:
    Commodity(const string& no, const string name, float price, int qty){
        sNo = no;
        sName = name;
        fPrice = price;
        iQuantity = qty;
    }

    void output(ostream& out) const{
        out << sNo << "," << sName << ","
            << fixed << setprecision(2) << fPrice << ","
            << iQuantity << endl;
    }
};

ostream& operator<<(ostream& out, const Commodity& c){
    c.output(out);
    return out;
}

int main(){
    ofstream fout("PriceList.csv");
    fout << "No,Name,Price,Quantity" << endl;  //标题行

    vector<Commodity> s = {
        {"A01","Apple",5.2764123f,2000},
        {"B02","Beef",65.741f,5000},
        {"C03","Cherry",117.4f,500}
    };

    for (auto& x:s){
        fout << x;                            //逐行与入文件
        cout << x;                            //逐行输出到控制台
    }

    fout.close();

    char sPath[512];
    assert(getcwd(sPath,512)!=NULL);
    cout << "PriceList.csv written to " << sPath << endl;
    return 0;
}
