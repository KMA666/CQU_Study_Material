//Project - StudentInfo
#include <iostream>
#include <vector>
#include <iomanip>
#include <boost/property_tree/ini_parser.hpp>
#include <boost/property_tree/ptree.hpp>
using namespace std;

class Score {
public:
    string sName;           //课程名称
    int iScore;             //分数
    Score(const string& name, const int score){
        sName = name;
        iScore = score;
    }
};

class Student {
    string sNo;             //学号
    string sName;           //姓名
    int iAge;               //年龄
    vector<Score> scores;   //成绩表

public:
    Student(){}
    Student(const string& no, const string& name, const int age){
        sNo = no; sName = name; iAge = age;
    }

    void addScore(const string& name, const int score){
        scores.emplace_back(name,score);
    }

    void save(const string& sFile){
        boost::property_tree::ptree s;

        s.put("basic.sNo",sNo);
        s.put("basic.sName",sName);
        s.put("basic.iAge",iAge);

        s.put("scores.size",scores.size());
        for (unsigned int i=0;i<scores.size();i++){
            auto& r = scores[i];
            s.put(string("scores.sName_")+std::to_string(i),r.sName);
            s.put(string("scores.iScore_")+std::to_string(i),r.iScore);
        }

        boost::property_tree::ini_parser::write_ini(sFile,s);
    }

    void load(const string& sFile){
        boost::property_tree::ptree s;
        boost::property_tree::ini_parser::read_ini(sFile,s);

        sNo = s.get("basic.sNo","");
        sName = s.get("basic.sName","");
        iAge = s.get("basic.iAge",0);

        scores.clear();
        auto size = s.get("scores.size",0);
        for (auto i=0;i<size;i++){
            auto sName = s.get(string("scores.sName_")+std::to_string(i),"");
            auto iScore = s.get(string("scores.iScore_")+std::to_string(i),0);
            scores.emplace_back(sName,iScore);
        }
    }

    void output(ostream& o){
        o << left;
        o << setw(10)<<"No."<<setw(15)<<"Name"<<setw(6)<<"Age"<<endl;
        o << "-------------------------------" << endl;
        o << setw(10)<<sNo<<setw(15)<<sName<<setw(6)<<iAge<<endl;
        o << "-------------------------------" << endl;
        for (auto& s:scores)
            o << setw(25) << s.sName << setw(6) << s.iScore << endl;
    }
};

int main() {
    Student dora1("20210426","Dora Chen",17);
    dora1.addScore("C++",97);
    dora1.addScore("Calculus",70);
    dora1.addScore("Economics",65);
    dora1.save("dora.ini");             //保存对象dora1至文件dora.ini

    Student dora2;
    dora2.load("dora.ini");             //从文件dora.ini读取内容至dora2
    dora2.output(cout);
    return 0;
}
