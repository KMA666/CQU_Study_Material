//Project - TextAndBinary
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>

int main(){
    struct stat fileStat;
    char sPath[512];
    getcwd(sPath,512);
    printf("cwd: %s\n",sPath);

    float fPi = 3.1415927f;
    FILE* fp = fopen("pi.txt","wt");
    fprintf(fp,"%.7f",(double)fPi);
    fclose(fp);
    stat("pi.txt",&fileStat);
    printf("size of text file pi.txt: %ld\n",fileStat.st_size);

    fp = fopen("pi.dat","wb");
    fwrite(&fPi,sizeof(float),1,fp);
    fclose(fp);
    stat("pi.dat",&fileStat);
    printf("size of binary file pi.dat: %ld\n",fileStat.st_size);

    fp = fopen("pi.dat","rb");
    fread(&fPi,sizeof(float),1,fp);
    fclose(fp);
    printf("read pi = %.7f\n",(double)fPi);

    return 0;
}
