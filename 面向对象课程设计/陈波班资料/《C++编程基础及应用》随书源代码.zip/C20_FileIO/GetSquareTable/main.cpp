//Project - GetSquareTable
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

int main() {
    string sPath = "D:/C2Cpp/C20_FileIO/build-BuildSquareTable-Desktop_Qt_6_2_4_MinGW_64_bit-Debug";
    ifstream f(sPath + "/SquareTable.txt");

    string t;
    getline(f,t);  cout << t << endl; //读取并输出标题行
    getline(f,t);  cout << t << endl; //读取分界线并输出

    while (!f.eof()){
        int n {-1}, n2 {-1};
        f >> n >> n2;
        if (n>=0 && n2>=0)
            cout << setw(6) << n << setw(14) << n2 << endl;
    }

    return 0;
}
