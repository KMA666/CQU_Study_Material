//Project - BinaryPriceListCpp
#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
using namespace std;

class Commodity {
public:
    int iNo;            //商品编号，不重复
    char sName[20];     //名称
    float fPrice;       //价格
    int iQuantity;      //在库数量
};

class CommodityFile {
private:
    fstream f;
    bool locateCommodity(int iNo){
        f.seekg(0,ios::end);  //读写位置移至末尾: 获取文件尺寸
        auto iFileSize = f.tellg();

        f.seekg(0,ios::beg);  //读写位置移至文件头
        int t;
        while (f.tellg()<iFileSize){
            f.read(reinterpret_cast<char*>(&t),sizeof(int));
            if (t==iNo){
                f.seekg(-sizeof(int),ios::cur);
                return true;
            }
            else
                f.seekg(sizeof(int)+sizeof(float)+20,ios::cur);
        }
        return false;
    }

public:
    CommodityFile(const string& sFile){
        //以附加模式打开->关闭:文件不存在时创建一个新文件
        f.open(sFile,ios::app|ios::out|ios::binary);
        f.close();
        f.open(sFile,ios::in | ios::out | ios::binary);
    }

    ~CommodityFile(){
        f.close();
    }

    void saveCommodity(const Commodity& c){
        if (!locateCommodity(c.iNo))
            f.seekp(0,ios::end);

        f.write(reinterpret_cast<const char*>(&c.iNo),sizeof(int));
        f.write(c.sName,20);
        f.write(reinterpret_cast<const char*>(&c.fPrice),sizeof(float));
        f.write(reinterpret_cast<const char*>(&c.iQuantity),sizeof(int));
    }

    bool loadCommodity(int iNo, Commodity& c){
        if (!locateCommodity(iNo))
            return false;

        f.read(reinterpret_cast<char*>(&c.iNo),sizeof(int));
        f.read(reinterpret_cast<char*>(c.sName),20);
        f.read(reinterpret_cast<char*>(&c.fPrice),sizeof(float));
        f.read(reinterpret_cast<char*>(&c.iQuantity),sizeof(int));
        return true;
    }
};

int main(){
    CommodityFile f("commodity.dat");

    Commodity c1 = {1,"Apple",5.2764123f,2000};
    f.saveCommodity(c1);
    Commodity c3 = {3,"Beef",65.741f,5000};
    f.saveCommodity(c3);
    Commodity c5 = {5,"Cherry",117.4f,500};
    f.saveCommodity(c5);

    strcpy(c3.sName,"Pork");
    f.saveCommodity(c3);

    Commodity t;
    cout << fixed << setprecision(2);
    cout << setw(6) << left << "No" << setw(20) << "Name" << setw(10)
         << right << "Price" << setw(10) << "Quantity" << endl;
    cout << "----------------------------------------------\n";
    for (int i=1;i<=5;i++){
        if (!f.loadCommodity(i,t))
            cout << setw(6) << left << i << setw(20) << "NA" << setw(10)
                 << right << 0.0 << setw(10) << 0 << endl;
        else
            cout << setw(6) << left << t.iNo << setw(20) << t.sName << setw(10)
                 << right << t.fPrice << setw(10) << t.iQuantity << endl;
    }

    return 0;
}
