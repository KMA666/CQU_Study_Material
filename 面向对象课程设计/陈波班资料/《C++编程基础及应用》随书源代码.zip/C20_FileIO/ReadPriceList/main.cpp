//Project - ReadPriceList
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>
using namespace std;

class Commodity{
    string sNo;       //产品编号
    string sName;     //产品名称
    float fPrice;     //价格
    int iQuantity;    //库存数量
public:
    void output(ostream& out) const{
        out << sNo << "," << sName << ","
            << fixed << setprecision(2) << fPrice << ","
            << iQuantity << endl;
    }

    void input(const string& s){
        stringstream ss(s); char c;
        getline(ss,sNo,',');
        getline(ss,sName,',');
        ss >> fPrice >> c >> iQuantity;
        return;
    }
};

ostream& operator<<(ostream& out, const Commodity& c){
    c.output(out);
    return out;
}

int main(){
    string sPath = "D:/C2Cpp/C20_FileIO/build-CreatePriceList-Desktop_Qt_6_2_4_MinGW_64_bit-Debug";
    ifstream f(sPath + "/PriceList.csv");

    string t;
    getline(f,t);      //读取并忽略标题行

    while(!f.eof()){
        getline(f,t);
        if (t.size()==0)
            continue;

        Commodity c;
        c.input(t);
        cout << c;
    }

    return 0;
}
