//Project - BuildSquareTable
#include <iostream>
#include <fstream>
#include <iomanip>
#include <unistd.h>
using namespace std;

int main(){
    char sPath[1024];
    getcwd(sPath,1024);                //获取当前工作路径至字符数组sPath

    ofstream fout("SquareTable.txt");  //创建输出文件流对象
    fout << setw(6) << "N" << setw(14) << "N^2" << endl;
    fout << "--------------------------------\n";
    for (int n=1;n<=20;n++)
        fout << setw(6) << n << setw(14) << n*n << endl;
    fout.close();                      //关闭输出文件流对象

    cout << "File: " << sPath << "/SquareTable.txt";
    return 0;
}
