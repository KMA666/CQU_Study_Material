//Project - LoopEditor
#include <iostream>
#include <vector>
using namespace std;

template <typename T>
void output(T begin, T end, const string& sTitle){
    cout << "----------" << sTitle << "------------\n";
    while (begin!=end)
        cout << *begin++ << ",";
    cout << endl;
}

int main() {
    vector<int> vi {1,-9,3,-2,0,7,-5};
    auto it = vi.begin();
    while (it != vi.end()){          //总是执行end()函数重新获取尾后迭代器
        if (*it < 0)
            it = vi.erase(it);       //erase()返回指向被删元素后一个元素的迭代器
        else{
            it = vi.insert(it,*it);  //insert()返回指向新增元素的迭代器
            it += 2;                 //后移两个位置以指向下一个待处理元素
        }
    }

    output(vi.begin(),vi.end(),"vector<int> vi");
    return 0;
}
