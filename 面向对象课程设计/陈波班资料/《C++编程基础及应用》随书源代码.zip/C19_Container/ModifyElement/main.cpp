//Project - ModifyElement
#include <iostream>
#include <list>
#include <vector>
using namespace std;

template <typename T>
void output(T begin, T end, const string& sTitle){
    cout << "----------" << sTitle << "------------\n";
    while (begin!=end)
        cout << *begin++ << ",";
    cout << endl;
}

int main() {
    vector<int> a;
    a.assign({0,1,2,3,4,5,6,7,8,9});
    *(a.begin()+3) = 99;
    output(a.cbegin(),a.cend(),"vector<int> a");

    list<int> b;
    b.assign(a.crbegin()+2,a.crend()-3);
    output(b.cbegin(),b.cend(), "list<int> b");

    return 0;
}


