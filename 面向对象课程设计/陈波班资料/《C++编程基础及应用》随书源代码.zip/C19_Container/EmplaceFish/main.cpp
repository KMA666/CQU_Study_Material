//Project - EmplaceFish
#include <iostream>
#include <vector>
using namespace std;

class Fish{
    string sName;
public:
    Fish(const char* name){
        sName = name;
        cout << "Fish constructor: " << sName << endl;
    }

    Fish(const Fish& r){
        sName = r.sName;
        cout << "Fish copy constructor: " << sName << endl;
    }
};

int main(){
    vector<Fish> v;
    v.reserve(10);  //提前分配10个元素的空间
    v.push_back(Fish("Tom"));
    v.push_back("Dora");
    v.emplace_back("Charlie");
    return 0;
}











