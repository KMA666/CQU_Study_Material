//Project - Algorithm2
#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
using namespace std;

int main(){
    list<string> ls {"91","42","2","52","11","2","37","2"};
    vector<int> vi;
    transform(ls.begin(),ls.end(),
              insert_iterator<vector<int>>(vi,vi.begin()),
              [](const string& s){return stoi(s);});

    cout << "elements of vi after transform: ";
    for_each(vi.begin(),vi.end(),[](int v){cout << v << " ";});

    cout << "\ncount(vi,2) = " << count(vi.cbegin(),vi.cend(),2);
    cout << "\nmax_element(vi) = " << *max_element(vi.cbegin(),vi.cend());
    cout << "\nmin_element(vi) = " << *min_element(vi.cbegin(),vi.cend());

    sort(vi.begin(),vi.end());
    cout << "\ncontent of vi after sort: ";
    for_each(vi.begin(),vi.end(),[](int v){cout << v << " ";});

    cout << "\n37 in vi: " <<
            (binary_search(vi.cbegin(),vi.cend(),37)?"yes":"no");
    cout << "\n96 in vi: " <<
            (binary_search(vi.cbegin(),vi.cend(),96)?"yes":"no");

    return 0;
}
