//Project - MessageContainer
#include <iostream>
#include <cstring>
#include <vector>
using namespace std;

class Message {
    char* buffer = nullptr;
public:
    int id = 0;
    Message(){ cout << "Constructor, id = " << id << endl; }

    Message(int id, const char* text){
        cout << "Constructor, id = " << id << endl;
        this->id = id;
        buffer = new char[strlen(text)+1];
        strcpy(buffer,text);
    }

    Message(const Message& r){
        cout << "Copy Constructor, from " << r.id << " to " << id << endl;
        id = r.id;
        if (buffer) delete [] buffer;
        buffer = new char[strlen(r.buffer)+1];
        strcpy(buffer,r.buffer);
    }

    Message(Message&& r) noexcept {
        cout << "Move Constructor, from " << r.id << " to " << id << endl;
        id = r.id;
        buffer = r.buffer;
        r.buffer = nullptr;
    }

    Message& operator=(const Message& r){
        cout << "operator=(), from " << r.id << " to " << id << endl;
        id = r.id;
        if (buffer) delete [] buffer;
        buffer = new char[strlen(r.buffer)+1];
        strcpy(buffer,r.buffer);
        return *this;
    }

    Message& operator=(Message&& r) noexcept {
        cout << "move operator=(), from " << r.id << " to " << id << endl;
        if (this==&r) return *this;
        id = r.id;
        if (buffer) delete[] buffer;
        buffer = r.buffer;
        r.buffer = nullptr;
        return *this;
    }

    const char* content() const { return buffer; }

    ~Message(){
        cout << "Destructor, id = " << id << endl;
        if (buffer) delete[] buffer;
    }
};

int main() {
    vector<Message> msgs;
    Message s1(1,"Hello, Hawaii.");
    Message s2(2,"Hello, Phuket.");
    msgs.push_back(s1);
    cout << "-------------------------------------\n";
    msgs.push_back(std::move(s2));
    return 0;
}
