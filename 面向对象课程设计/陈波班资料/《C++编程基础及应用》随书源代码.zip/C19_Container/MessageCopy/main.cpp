//Project - MessageCopy
#include <iostream>
#include <cstring>
using namespace std;

class Message {
    char* buffer = nullptr;
public:
    int id = 0;
    Message(){ cout << "Constructor, id = " << id << endl; }

    Message(int id, const char* text){
        cout << "Constructor, id = " << id << endl;
        this->id = id;
        buffer = new char[strlen(text)+1];
        strcpy(buffer,text);
    }

    Message(const Message& r){
        cout << "Copy Constructor, from " << r.id << " to " << id << endl;
        id = r.id;
        if (buffer) delete [] buffer;
        buffer = new char[strlen(r.buffer)+1];
        strcpy(buffer,r.buffer);
    }

    Message& operator=(const Message& r){
        cout << "operator=(), from " << r.id << " to " << id << endl;
        id = r.id;
        if (buffer) delete [] buffer;
        buffer = new char[strlen(r.buffer)+1];
        strcpy(buffer,r.buffer);
        return *this;
    }

    const char* content() const { return buffer; }

    ~Message(){
        cout << "Destructor, id = " << id << endl;
        if (buffer) delete[] buffer;
    }
};

Message fetchMessage(){
    Message m(1,"Washington, this is pearl harbour, we are under japanese attack!");
    return m;
}

int main() {
    Message s;
    s = fetchMessage();
    cout << "Message " << s.id << ": " << s.content() << endl;
    return 0;
}
