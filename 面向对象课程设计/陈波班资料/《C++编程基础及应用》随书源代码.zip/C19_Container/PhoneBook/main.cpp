//Project - PhoneBook
#include <iostream>
#include <map>
using namespace std;

int main() {
    map<string, string> phoneBook = {
        {"Peter","6716-4203"},
        {"Dora","6546-2708"}
    };

    phoneBook["Alex"] = "6511-2002";
    phoneBook.insert(make_pair("Betty","6512-7252"));
    phoneBook.emplace("Betty","8623-4500");
    phoneBook.erase("Dora");

    cout << "phoneBook[\"Peter\"]: " << phoneBook["Peter"] << endl;
    cout << "phoneBook.count(\"Peter\"): " << phoneBook.count("Peter") << endl;
    auto itr = phoneBook.find("Peter");
    if (itr!=phoneBook.end())
        cout << "itr->second: " << itr->second << endl;

    cout << "--------Traverse of Phone Book-----------\n";
    for (auto& e:phoneBook)
        cout << e.first << "\t" << e.second << endl;

    cout << "--------Reversed Traverse of Phone Book-----------\n";
    auto it = phoneBook.crbegin();
    while (it!=phoneBook.crend()){
        cout << it->first << "\t" << it->second << endl;
        it++;
    }

    return 0;
}
