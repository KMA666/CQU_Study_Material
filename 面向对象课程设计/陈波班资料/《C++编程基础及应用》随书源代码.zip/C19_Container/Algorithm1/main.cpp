//Project - Algorithm1
#include <iostream>
#include <vector>
#include <deque>
#include <algorithm>
using namespace std;

void display(const string& s){ cout << s << " "; }

int main(){
    cout << "Sort alphabetically: ";
    vector<string> vs {"tom","angela","dorothy","jack"};
    sort(vs.begin(),vs.end());
    for_each(vs.begin(),vs.end(),display);

    cout << "\nSort by length: ";
    deque<string> ds {"tom","angela","dorothy","jack"};
    sort(ds.begin(),ds.end(),
         [](string& s1,string& s2){return s1.size()<s2.size();});
    for_each(ds.begin(),ds.end(),display);

    return 0;
}
