//Project - VectorInit
#include <iostream>
#include <vector>
using namespace std;

template <typename T>
void outputVector(const vector<T> v){
    for (auto x:v)
        cout << x << ", ";
    cout << endl;
}

int main() {
    vector<string> v0 {"good", "better", "best"};
    vector<string> v1 = {"good", "better", "best"};
    outputVector(v0);
    outputVector(v1);

    vector<string> v2(5,"hi");
    outputVector(v2);

    vector<int> v3(6);
    outputVector(v3);

    vector<int> v4 {6};
    vector<int> v5 {6,1};

    return 0;
}
