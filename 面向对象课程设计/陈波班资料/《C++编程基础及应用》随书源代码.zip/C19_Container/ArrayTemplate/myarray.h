//myarray.h
#ifndef MYARRAY_H
#define MYARRAY_H
#include <initializer_list>

template <class T,  int size>
class MyArray {
    T* buffer = nullptr;
public:
    MyArray(){
        buffer = new T[size];
    }

    MyArray(std::initializer_list<T> v);

    ~MyArray(){
        delete[] buffer;
    }

    int elementsCount(){
        return size;
    }

    T& operator[](int idx){
        if (idx<0 || idx>=size)
            throw "index out of range.";
        return buffer[idx];
    }
};

template <class T,  int size>
MyArray<T, size>::MyArray(std::initializer_list<T> v){
    buffer = new T[size];
    auto idx = 0;
    for (auto it = v.begin(); it!=v.end();it++){
        if (idx>=size)
            break;
        buffer[idx++] = *it;
    }
}

#endif // MYARRAY_H
