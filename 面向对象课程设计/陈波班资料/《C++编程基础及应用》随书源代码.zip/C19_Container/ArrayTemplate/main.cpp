//Project - ArrayTemplate
#include <iostream>
#include "myarray.h"
using namespace std;

int main() {
    MyArray<int,4> a {66,77,88,99};
    for (auto i=0;i<a.elementsCount();i++)
        cout << a[i] << ",";
    cout << endl;

    MyArray<string,3> b {"good","better","best"};
    for (auto i=0;i<b.elementsCount();i++)
        cout << b[i] << ",";

    cout << endl << b[6];
    return 0;
}
