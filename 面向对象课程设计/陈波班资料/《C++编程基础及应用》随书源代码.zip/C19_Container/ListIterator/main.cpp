//Project - ListIterator
#include <iostream>
#include <list>
using namespace std;

int main() {
    list<double> a {1,10,100,1000};
    auto it = a.rbegin();
    while (it!=a.rend()){
        *it = (*it)*1.2;
        cout << *it << ",";
        it++;
    }
    return 0;
}

