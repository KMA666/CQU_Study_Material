//Project - LeftRight
#include <iostream>
using namespace std;

int main() {
    int a = 69;
    int&& arr1 = a;  //错误：右值引用不可以直接引用左值对象
    int&& arr2 = std::move(a); //正确：将左值引用强制类型转换成右值引用
    return 0;
}
