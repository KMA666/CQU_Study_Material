//Project - ThisPerson
#include <iostream>
using namespace std;

class Person{
public:
    string sName;       //姓名
    int iWeight;        //体重，以克为单位

    Person(){
        cout << "Person::Person(), this = " << this << endl;
        this->sName = "N/A"; //sName = "N/A";
        this->iWeight = 50000;
    }

    void eat(int weight){
        cout << "Person::eat(), this = " << this << endl;
        iWeight += weight;
        //this->iWeight += weight;
    }
};  //注意末尾的分号不能少

int main(){
    Person tom;
    Person dora;
    cout << "&tom = " << &tom << ", &dora = " << &dora << endl;

    tom.sName = "Tom";
    dora.sName = "Dora";
    dora.eat(100);

    cout << "Name: " << tom.sName << ", Weight: " << tom.iWeight << endl;
    cout << "Name: " << dora.sName << ", Weight: " << dora.iWeight << endl;
    return 0;
}

