//Project - SimplePerson
#include <iostream>
using namespace std;

enum class GenderType{
    male = 0, female = 1
};

class Person{
public:
    string sName;           //姓名
    string sID;             //身份证号
    GenderType gender = GenderType::male; //性别
    int iWeight {50000};    //体重，以克为单位

    Person(const string& id = "N/A", const string& name = "N/A" ){
        sID = id;
        sName = name;
        cout << "Person::Person(), sName = " << sName << endl;
    }

    void speak(){
        cout << "Person::speak()" << endl;
        cout << "I am " << sName <<", Nice to meet you here." << endl;
    }

    void eat(int weight){
        iWeight += weight;
        cout << "I just ate " << weight << " gram's food." << endl;
    }

    string description(){
        char buffer[1024];  //注意缓冲区尺寸，当心溢出
        sprintf(buffer,"ID:     %s\nName:   %s\nGender: %s\nWeight: %d",
                sID.c_str(),sName.c_str(),
                gender==GenderType::male?"Male":"Female",iWeight);
        return buffer;
    }
};  //注意末尾的分号不能少

int main(){
    Person peter("3604020001", "Peter Lee");
    peter.eat(100);
    peter.speak();
    cout << peter.description() << endl;

    cout << "-----------------------------------------" << endl;

    Person dora;
    dora.sID = "3604020002";
    dora.sName = "Dora Henry";
    dora.speak();
    cout << dora.description() << endl;

    return 0;
}

