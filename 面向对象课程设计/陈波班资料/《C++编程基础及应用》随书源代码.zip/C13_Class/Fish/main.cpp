//Project - Fish
#include <iostream>
using namespace std;

class Fish {
public:
    string sName;
    Fish(const string& name){
        sName = name;
        cout << "Fish Constructor called: " << sName << endl;
    }

    Fish(){
        sName = "N/A";
        cout << "Fish Constructor called: " << sName << endl;
    }

    ~Fish(){
        cout << "Fish Destructor called: "  << sName << endl;
        //同样存在this指针，sName事实上通过this指针访问
    }
};

int main() {
    Fish tom("tom");
    Fish dora("dora");
    Fish nameless;

    return 0;
}
