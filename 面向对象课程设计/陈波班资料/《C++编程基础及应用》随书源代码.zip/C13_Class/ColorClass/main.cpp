//Project - ColorClass
#include <iostream>
using namespace std;

enum class Color {
    red, orange, yellow=100, green, blue, violet
}; //注意末位分号不能少
//   0     1      100        101    102   103

string getColor(Color c){
    switch (c){
    case Color::red:
        return "red";
    case Color::orange:
        return "orange";
    case Color::yellow:
        return "yellow";
    case Color::green:
        return "green";
    case Color::blue:
        return "blue";
    case Color::violet:
        return "violet";
    default:
        return "error";
    }
}

int main(){
    cout << "sizeof(Color) = " << sizeof(Color) << endl;
    Color color = Color::blue;
    color = Color(103);   //violet
    cout << "violet = " << int(Color::violet) << endl;
    cout << "color = " << getColor(Color::green);
    return 0;
}
