#include "threadnetworkbuilder.h"
#include <QSqlQuery>
#include <QSqlRecord>
#include <QSqlField>
#include <QSqlError>
#include "dbhelper.h"
#include "poet.h"

ThreadNetworkBuilder::ThreadNetworkBuilder() {
   //按Qt文档，禁止通过terminate()函数终止线程
   setTerminationEnabled(false);
}

void ThreadNetworkBuilder::run() {
    DBHelper::openDatabase();  //打开线程数据库连接
    buildPoetsNetwork();
    DBHelper::closeDatabase(); //关闭线程数据库连接
}

void ThreadNetworkBuilder::requestTerminate() {
    //主线程要求线程终止
    bRequestTerminated = true;
    qDebug() << "ThreadNetworkBuilder - requestTerminate.";
}

void ThreadNetworkBuilder::buildPoetsNetwork() {
    loadPoemsPoets();

    int idx = 0;
    QVariantList authorids, refids, poemids;
    for (auto& m:poems){
        if (bRequestTerminated)
            return;

        int t = 30 + 65 *(idx++)/poems.size();
        if (t>iProgress){
            iProgress = t;
            emit progressUpdate();
        }

        auto authorid = mapPoets[m.sAuthor].iId;
        for (auto& t:mapPoets.values()) {
            if (m.sTitle.contains(t.sName) || m.sContent.contains(t.sName)){
                //直接引用了诗人的本名
                authorids << authorid;
                refids << t.iId;
                poemids << m.iId;
                continue;
            }

            //尝试别名
            for (auto& altName:t.altNames){
                if (m.sTitle.contains(altName) || m.sContent.contains(altName)){
                    authorids << authorid;
                    refids << t.iId;
                    poemids << m.iId;
                    break;
                }
            }
        }
    }

    QSqlQuery q;
    Q_ASSERT(q.exec("DELETE FROM reference"));

    q.clear();
    q.prepare("INSERT INTO reference VALUES (?,?,?)");
    q.addBindValue(authorids); q.addBindValue(refids);
    q.addBindValue(poemids);

    DBHelper::db.transaction();    //开始数据库事务
    if (!q.execBatch()){
        qDebug() << q.lastError();
        DBHelper::db.rollback();   //回滚数据库事务
        return;
    }
    DBHelper::db.commit();         //提交数据库事务

    iReferenceCount = int(refids.size());
    iProgress = 100;
    emit progressUpdate();
}

void ThreadNetworkBuilder::loadPoemsPoets() {
    QSqlQuery q;
    Q_ASSERT(q.exec("SELECT count(*) FROM poem"));
    Q_ASSERT(q.next());
    auto size = q.record().field(0).value().toInt();
    Q_ASSERT(size>0);

    int idx = 0;
    q.clear();
    Q_ASSERT(q.exec("SELECT id, title, author, content FROM poem"));
    while (q.next()) {
        if (bRequestTerminated)
            return;

        int t = 30 * (idx++) / size;
        if (t>iProgress){
            iProgress = t;
            emit progressUpdate();
        }

        auto r = q.record();
        auto id = r.field(0).value().toInt();
        auto title = r.field(1).value().toString();
        auto author = r.field(2).value().toString();
        auto content = r.field(3).value().toString();

        Poem m(id,title,author,content);
        if (mapPoets.contains(author))
            poems.append(m); //诗人author已存在于映射mapPoets中
        else {
            Poet t;
            if (Poet::getPoetByName(author,t)){
                //在poet表中找到诗人author
                poems.append(m);
                mapPoets[author] = t;
            }
        }
    }
}
