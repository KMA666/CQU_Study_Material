#include "mainwidget.h"
#include "ui_mainwidget.h"
#include <QFile>
#include <QTextStream>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QSqlField>
#include <QSqlError>
#include <QSqlDatabase>
#include "buildnetwork.h"
#include "dbhelper.h"
#include "poet.h"
#include "reference.h"
#include <QSet>
#include <QProcess>

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainWidget) {
    ui->setupUi(this);
    DBHelper::openDatabase();
}

MainWidget::~MainWidget() {
    delete ui;
    DBHelper::closeDatabase();
}

int MainWidget::parsePoemsIntoDatabase() {
    QString sFile = DBHelper::sProjectPath + "/data/qts_zht.txt";
    if (!(QFile::exists(sFile))) {
        qDebug() << "Error: missing QTS file " << sFile;
        return -1;
    }

    auto q = QSqlQuery();
    q.prepare("DROP TABLE IF EXISTS poem; ");
    if (!q.exec()){
        qDebug() << q.lastError();
        return -1;
    }

    q.clear();
    q.prepare("CREATE TABLE poem(id INT PRIMARY KEY ASC, "
              "title TEXT, author TEXT, content TEXT);");
    if (!q.exec()){
        qDebug() << q.lastError();
        return -1;
    }

    auto idx = 0;
    QVariantList ids, titles, authors, contents;

    QFile f(sFile);
    Q_ASSERT(f.open(QIODevice::ReadOnly));
    QTextStream fs(&f);
    fs.setEncoding(QStringConverter::Utf8);
    while (!fs.atEnd()){
        auto line = fs.readLine();
        line.replace("\t"," ");
        auto r = line.split(" ");
        if (r.size()==4){
            ids << idx++; titles << r[1]; authors << r[2]; contents << r[3];
        }
    }
    f.close();

    q.clear();
    q.prepare("INSERT INTO poem VALUES (?,?,?,?)");
    q.addBindValue(ids);     q.addBindValue(titles);
    q.addBindValue(authors); q.addBindValue(contents);

    DBHelper::db.transaction();    //开始数据库事务
    if (!q.execBatch()){
        qDebug() << q.lastError();
        DBHelper::db.rollback();   //回滚数据库事务
        return -1;
    }
    DBHelper::db.commit();         //提交数据库事务

    return int(ids.size());
}

void MainWidget::on_pbParseQTS_released(){
    auto r = parsePoemsIntoDatabase();
    ui->textBrowser->setHtml(r<0?QString("解析全唐诗文本并导入数据库失败!")
        :QString("%1首全唐诗被解析并存入数据库peom表。").arg(r));
}

void MainWidget::on_pbConstructNetwork_released() {
    auto dlg = QSharedPointer<BuildNetwork>(new BuildNetwork(this));
    dlg->exec();
    auto r = dlg->iReferenceCount;
    ui->textBrowser->setHtml(r<=0?QString("关系网络构建过程中途中断。")
        :QString("关系网络构建完成，共发现%1条引用关系。").arg(r));
}

void MainWidget::on_pbQueryReference_released() {
    Poet poet1;
    if (!Poet::getPoetByName(ui->leRefPoet1->text().trimmed(),poet1))
        return;
    Poet poet2;
    if (!Poet::getPoetByName(ui->leRefPoet2->text().trimmed(),poet2))
        return;

    QString sHtml;
    auto poems1 = Reference::getReferencePoems(poet1.iId,poet2.iId);
    sHtml += "<table><tr><td bgcolor='#e8f4fe'>";
    sHtml += toHtml(poet1);
    sHtml += QString("<font size='4' color=#369ff3><center><br>"
                     "%1在%2首诗中提到了%3<br></center></font>")
            .arg(poet1.sName).arg(poems1.size()).arg(poet2.sName);
    for (auto& m:poems1)
        sHtml += toHtml(m);
    sHtml += "</td><td bgcolor='#fcfdf8'>";

    auto poems2 = Reference::getReferencePoems(poet2.iId,poet1.iId);
    sHtml += toHtml(poet2);
    sHtml += QString("<font size='4' color=#369ff3><center><br>"
                     "%1在%2首诗中提到了%3<br></center></font>")
            .arg(poet2.sName).arg(poems2.size()).arg(poet1.sName);
    for (auto& m:poems2)
        sHtml += toHtml(m);
    sHtml += "</td></tr></table>";

    ui->textBrowser->setHtml(sHtml);
}

QString MainWidget::toHtml(const Poet& t) {
    QString s = t.sName + "( ";
    for (auto& x:t.altNames)
        s = s + x + " ";
    s += ")";
    return QString("<center><font size='4'>%1</font><br>"
                   "<font size='2'>%2 ~ %3</font></center><hr>")
           .arg(s).arg(t.iBirthYear).arg(t.iDeathYear);
}

QString MainWidget::toHtml(const Poem& m) {
    QString t;
    t += QString("<center><h3>%1</h3></center>").arg(m.sTitle);
    t += QString("<center>%1</center>").arg(m.sAuthor);

    QString c = m.sContent;
    c.replace("。","。<br>");
    t += QString("<center>%1</center>").arg(c);
    return t;
}

void MainWidget::on_pbFriendCycle_released() {
    Poet m;
    if (!Poet::getPoetByName(ui->lePoetFriendCycle->text().trimmed(),m)){
        ui->textBrowser->setHtml(
                    "<h3>诗人姓名不存在，注意数据库存储的姓名为繁体中文.</h3>");
        return;
    }

    QVector<Reference> r = Reference::getFriendCycle(m.iId);
    QString sFileName = DBHelper::sProjectPath + "/html/friendcycle.html";
    writeHtmlFile(sFileName,toHtml(r));

    QStringList t;
    t << sFileName.replace("/","\\");
    QProcess::startDetached("explorer",t);
}

QString MainWidget::toHtml(const QVector<Reference>& n) {
    auto sHtmlHead = readFile(DBHelper::sProjectPath + "/html/html_head.txt");
    auto sHtmlTail = readFile(DBHelper::sProjectPath + "/html/html_tail.txt");

    QString sLinks = "links: [\n";
    QString sLinkFormat =
            "{source:'%1',target:'%2',lineStyle:{normal:{width: %3}}},";
    QSet<QString> authorNames;
    for (auto& x:n){
        auto sAuthorName = Poet::getPoetNameById(x.iAuthorId);
        auto sRefName = Poet::getPoetNameById(x.iRefId);
        sLinks += sLinkFormat.arg(sAuthorName).arg(sRefName).arg(sqrt(x.iCount));
        authorNames << sAuthorName <<  sRefName;
    }
    sLinks += "],\n";

    QString sNodes = "data:[\n";
    QString sItemFormat = "{name: '%1'},\n";
    for (auto& x:authorNames)
        sNodes += sItemFormat.arg(x);
    sNodes += "],\n";

    return sHtmlHead + sNodes + sLinks + sHtmlTail;
}

QString MainWidget::readFile(const QString filename) {
    if (!(QFile::exists(filename))) {
        qDebug() << "Error: missing file... " << filename;
        return "";
    }

    QFile f(filename);
    Q_ASSERT(f.open(QIODevice::ReadOnly));
    QTextStream fs(&f);
    fs.setEncoding(QStringConverter::Utf8);
    auto s = fs.readAll();
    f.close();
    return s;
}

void MainWidget::writeHtmlFile(const QString& filename,
                               const QString& sContent) {
    QFile f(filename);
    Q_ASSERT(f.open(QIODevice::WriteOnly));
    f.write(sContent.toUtf8());
    f.close();
}

void MainWidget::exploreNetwork(int iLimit) {
    QVector<Reference> r = Reference::getReferences(iLimit);
    QString sFileName = DBHelper::sProjectPath +
            QString("/html/network%1.html").arg(iLimit);
    writeHtmlFile(sFileName,toHtml(r));

    QStringList t;
    t << sFileName.replace("/","\\");
    QProcess::startDetached("explorer",t);
}

void MainWidget::on_pbNetwork50_released() {
    exploreNetwork(50);
}

void MainWidget::on_pbNetwork100_released() {
    exploreNetwork(100);
}

void MainWidget::on_pbNetwork200_released() {
    exploreNetwork(200);
}

void MainWidget::on_pbNetwork500_released() {
    exploreNetwork(500);
}
