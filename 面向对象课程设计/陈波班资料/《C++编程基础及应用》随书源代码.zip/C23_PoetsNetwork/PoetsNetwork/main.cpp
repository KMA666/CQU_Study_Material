//Project - PoetsNetwork
#include "mainwidget.h"
#include "dbhelper.h"
#include <QApplication>
#include <QFile>

int main(int argc, char *argv[]) {
    if (!QFile::exists(DBHelper::sProjectPath)){
        qDebug() << DBHelper::sProjectPath << " does not exist!";
        Q_ASSERT(1==2);
        return 0;
    }

    QApplication a(argc, argv);
    MainWidget w;
    w.show();
    return a.exec();
}
