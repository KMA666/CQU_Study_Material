#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QVector>
#include "poem.h"
#include "reference.h"
#include "poet.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWidget; }
QT_END_NAMESPACE

class MainWidget : public QWidget {
    Q_OBJECT
public:
    MainWidget(QWidget *parent = nullptr);
    ~MainWidget();

private slots:
    void on_pbParseQTS_released();
    void on_pbConstructNetwork_released();
    void on_pbQueryReference_released();
    void on_pbFriendCycle_released();
    void on_pbNetwork50_released();
    void on_pbNetwork100_released();
    void on_pbNetwork200_released();
    void on_pbNetwork500_released();

private:
    Ui::MainWidget *ui;
    int parsePoemsIntoDatabase();
    QString toHtml(const Poem& m);
    QString toHtml(const Poet& t);
    QString toHtml(const QVector<Reference>& n);
    QString readFile(const QString filename);
    void writeHtmlFile(const QString& filename, const QString& sContent);
    void exploreNetwork(int iLimit);
};
#endif // MAINWIDGET_H
