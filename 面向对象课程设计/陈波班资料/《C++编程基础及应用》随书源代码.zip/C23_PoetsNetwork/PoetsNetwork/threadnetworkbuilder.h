#ifndef THREADNETWORKBUILDER_H
#define THREADNETWORKBUILDER_H
#include <QThread>
#include <QVector>
#include <QMap>
#include "poem.h"
#include "poet.h"

class ThreadNetworkBuilder:public QThread {
    Q_OBJECT
public:
    ThreadNetworkBuilder();
    void run() override;
    volatile int iProgress {0};   //进度，0-100
    void requestTerminate();      //主线程要求线程终止
    volatile int iReferenceCount = 0; //成功写入数据库的引用记录数

signals:
    void progressUpdate();

private:
    QVector<Poem> poems;
    QMap<QString,Poet> mapPoets;
    void loadPoemsPoets();
    void buildPoetsNetwork();
    volatile bool bRequestTerminated {false};
};

#endif // THREADNETWORKBUILDER_H
