#ifndef BUILDNETWORK_H
#define BUILDNETWORK_H
#include <QDialog>
#include <QSharedPointer>
#include "threadnetworkbuilder.h"

namespace Ui {
class BuildNetwork;
}

class BuildNetwork : public QDialog {
    Q_OBJECT
public:
    explicit BuildNetwork(QWidget *parent = nullptr);
    ~BuildNetwork();
    int iReferenceCount = 0;

protected:
    void reject();

private slots:
    void progressUpdate();      //进度更新槽函数
    void builderFinished();     //线程结束槽函数
    void on_pbAbort_released();

private:
    Ui::BuildNetwork *ui;
    QSharedPointer<ThreadNetworkBuilder> builder = nullptr;
    bool bCloseEnabled {false};
};

#endif // BUILDNETWORK_H
