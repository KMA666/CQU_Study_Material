#include "reference.h"
#include <QSqlQuery>
#include <QSqlRecord>
#include <QSqlField>

QVector<Poem> Reference::getReferencePoems(int authorid, int refid){
    QSqlQuery q;
    QString sSql =
        QString("SELECT id, title, author, content FROM poem WHERE id IN "
        "(SELECT poemid FROM reference WHERE authorid = %1 and refid = %2)")
            .arg(authorid).arg(refid);
    Q_ASSERT(q.exec(sSql));

    QVector<Poem> t;
    while (q.next()){
        auto r = q.record();
        t << Poem(r.field(0).value().toInt(),
                      r.field(1).value().toString(),
                      r.field(2).value().toString(),
                      r.field(3).value().toString());
    }

    return t;
}

QVector<Reference> Reference::getFriendCycle(int authorid) {
    QSqlQuery q;
    QString sSql = QString(
        "SELECT authorid,refid,count(*) as cnt FROM reference "
        "WHERE authorid=%1 or refid=%2 GROUP BY authorid, refid")
            .arg(authorid).arg(authorid);

    Q_ASSERT(q.exec(sSql));

    QVector<Reference> t;
    while (q.next()){
        auto r = q.record();
        t << Reference(r.field(0).value().toInt(),
                       r.field(1).value().toInt(),
                       r.field(2).value().toInt());
    }

    return t;
}

QVector<Reference> Reference::getReferences(int iLimit) {
    QSqlQuery q;
    QString sSql = QString(
        "SELECT authorid,refid,count(*) as cnt FROM reference "
        "GROUP BY authorid, refid ORDER BY cnt DESC LIMIT %1").arg(iLimit);

    Q_ASSERT(q.exec(sSql));

    QVector<Reference> t;
    while (q.next()){
        auto r = q.record();
        t << Reference(r.field(0).value().toInt(),
                       r.field(1).value().toInt(),
                       r.field(2).value().toInt());
    }

    return t;
}

