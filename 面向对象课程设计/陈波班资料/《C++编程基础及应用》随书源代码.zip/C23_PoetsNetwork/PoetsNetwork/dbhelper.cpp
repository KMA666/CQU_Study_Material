#include "dbhelper.h"
#include <QFile>
#include <QDebug>

QSqlDatabase DBHelper::db;

bool DBHelper::openDatabase() {
    QString sDBFile = sProjectPath + "/data/data.db";
    if (!(QFile::exists(sDBFile))) {
        qDebug() << "Error: missing database file " << sDBFile;
        return false;
    }

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(sDBFile);
    if (db.open())
        qDebug() << "Database opened successfully:" << sDBFile;
    else
        qDebug() << "Database open failed:" << sDBFile;

    return db.isOpen();
}

void DBHelper::closeDatabase(){
    if (db.isOpen())
        db.close();
}

QString DBHelper::sProjectPath = "d:/C2Cpp/C23_PoetsNetwork";

