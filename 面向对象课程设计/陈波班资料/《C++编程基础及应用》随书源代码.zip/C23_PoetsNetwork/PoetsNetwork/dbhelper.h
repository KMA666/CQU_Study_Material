#ifndef DBHELPER_H
#define DBHELPER_H
#include <QtSql/QSqlDatabase>

class DBHelper {
public:
    static QSqlDatabase db;
    static bool openDatabase();
    static void closeDatabase();
    static QString sProjectPath;
};

#endif // DBHELPER_H
