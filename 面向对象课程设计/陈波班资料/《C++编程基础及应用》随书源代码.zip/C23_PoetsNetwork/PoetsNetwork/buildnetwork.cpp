#include "buildnetwork.h"
#include "ui_buildnetwork.h"
#include "dbhelper.h"

BuildNetwork::BuildNetwork(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::BuildNetwork)
{
    ui->setupUi(this);

    ui->progressBar->setRange(0, 100);
    ui->progressBar->setValue(0);
    setFixedSize(width(), height());

    DBHelper::closeDatabase();  //关闭主线程中的数据库连接

    builder = QSharedPointer<ThreadNetworkBuilder>(new ThreadNetworkBuilder());
    connect(builder.get(), &ThreadNetworkBuilder::progressUpdate,
            this, &BuildNetwork::progressUpdate);
    connect(builder.get(), &ThreadNetworkBuilder::finished,
            this, &BuildNetwork::builderFinished);
    builder->start();
}

BuildNetwork::~BuildNetwork() {
    builder = nullptr;
    delete ui;
}

void BuildNetwork::progressUpdate() {
    if (builder)
        ui->progressBar->setValue(builder->iProgress);
}

void BuildNetwork::builderFinished() {
    if (builder)
        iReferenceCount = builder->iReferenceCount;
    bCloseEnabled = true;

    DBHelper::openDatabase();  //重新打开主线程的数据库连接
    close();
}

void BuildNetwork::on_pbAbort_released() {
    if (builder)
        builder->requestTerminate();
}

void BuildNetwork::reject() {
    if (bCloseEnabled){
        QDialog::reject();
    }
}


