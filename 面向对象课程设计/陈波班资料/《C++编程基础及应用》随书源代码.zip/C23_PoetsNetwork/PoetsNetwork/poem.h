#ifndef POEM_H
#define POEM_H
#include <QString>

class Poem {
public:
    Poem(int id, const QString& title,
         const QString& author, const QString& content):
         iId(id),sTitle(title),sAuthor(author),sContent(content){ }

    int iId = 0;
    QString sTitle;
    QString sAuthor;
    QString sContent;
};

#endif // POEM_H
