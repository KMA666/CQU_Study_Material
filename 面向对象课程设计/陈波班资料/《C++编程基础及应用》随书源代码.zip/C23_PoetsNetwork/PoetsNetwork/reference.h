#ifndef REFERENCE_H
#define REFERENCE_H
#include <QVector>
#include "poem.h"

class Reference {
public:
    int iAuthorId;
    int iRefId;
    int iCount;
    Reference(int authorid, int refid, int cnt):
        iAuthorId(authorid),iRefId(refid),iCount(cnt){ }
    static QVector<Poem> getReferencePoems(int authorid, int refid);
    static QVector<Reference> getFriendCycle(int authorid);
    static QVector<Reference> getReferences(int iLimit);
};

#endif // REFERENCE_H
