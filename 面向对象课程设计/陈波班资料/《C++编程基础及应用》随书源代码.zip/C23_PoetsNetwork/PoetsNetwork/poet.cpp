#include "poet.h"
#include <QSqlQuery>
#include <QSqlRecord>
#include <QSqlField>

Poet::Poet(int id, const QString& name, int birthyear, int deathyear){
    iId = id; sName = name; iBirthYear = birthyear; iDeathYear = deathyear;
}

bool Poet::getPoetByName(const QString& name, Poet& poet){
    int iTangStart = 618, iTangEnd = 907;  //唐建立及灭亡年份
    QVector<Poet> candidates;

    QSqlQuery q;
    auto sSql = QString("SELECT id, name, birthyear, deathyear "
                        "FROM poet WHERE name like '%%1%'").arg(name);
    Q_ASSERT(q.exec(sSql));
    while (q.next()){
        auto r = q.record();
        auto id = r.field(0).value().toInt();
        auto name = r.field(1).value().toString();
        auto birthyear = r.field(2).value().toInt();
        auto deathyear = r.field(3).value().toInt();
        if (birthyear && deathyear){
            if (birthyear < deathyear and deathyear > iTangStart){
                poet = Poet(id,name,birthyear,deathyear);
                poet.altNames = getAltNamesById(id);
                return true;
            }
        }
        else if (birthyear || deathyear){
            auto year = birthyear?birthyear:deathyear;
            if (year>iTangStart && year<iTangEnd)
                candidates.emplace_back(id,name,birthyear,deathyear);
        }
    }

    if (candidates.size()!=1)
        return false;

    poet = candidates[0];
    poet.altNames = getAltNamesById(poet.iId);
    return true;
}

QVector<QString> Poet::getAltNamesById(int id) {
    QSqlQuery q;
    Q_ASSERT(q.exec(QString("SELECT name FROM altname WHERE id = %1").arg(id)));

    QVector<QString> r;
    while (q.next()) {
        auto n = q.record().field(0).value().toString();
        if (n.size()>1) //别名至少要有两个字，单字别名为 刺，德
            r << n;
    }

    return r;
}

QString Poet::getPoetNameById(int id) {
    QSqlQuery q;
    Q_ASSERT(q.exec(QString("SELECT name FROM poet WHERE id = %1").arg(id)));
    if (q.next())
        return q.record().field(0).value().toString();
    else
        return "N/A";
}
