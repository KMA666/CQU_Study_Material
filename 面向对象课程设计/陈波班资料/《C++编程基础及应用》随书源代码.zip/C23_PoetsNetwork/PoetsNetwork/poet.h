#ifndef POET_H
#define POET_H
#include <QString>
#include <QVector>

class Poet {
public:
    Poet(){}
    Poet(int id, const QString& name, int birthyear, int deathyear);
    int iId = 0;
    QString sName;
    int iBirthYear = 0;
    int iDeathYear = 0;
    QVector<QString> altNames;

    static bool getPoetByName(const QString& name, Poet& poet);
    static QVector<QString> getAltNamesById(int id);
    static QString getPoetNameById(int id);
};

#endif // POET_H
