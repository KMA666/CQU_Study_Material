//Project - Assignment
#include <iostream>
using namespace std;

int main(){
    int a, b;
    a = b = 3;
    cout << "a = " << a << ", b = " << b << endl;

    if (a=4)
        cout << "a is equal to 4.";
    else
        cout << "a is not equal to 4.";

    return 0;
}
