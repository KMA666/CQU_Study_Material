//Project - ListInit
#include <iostream>
using namespace std;

int main(){
    char c = 712;         //允许，但会溢出
    char d {66};          //允许，66在char的储值范围内
    char e {712};         //不允许，712超过char的储值范围
    unsigned int f {-1};  //不允许，unsigned int只能存非负整数
    int g {3.12};         //不允许，收窄会导致精度丢失

    return 0;
}
