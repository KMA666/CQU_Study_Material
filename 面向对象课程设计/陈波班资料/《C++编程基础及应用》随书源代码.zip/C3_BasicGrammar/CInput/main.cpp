//Project - CInput
#include <stdio.h>
#include <math.h>

int main() {
    int iAge = 0,iHeight = 0;
    float fWeight = 0;

    printf("Please input your age, weight(kg):\n");
    scanf("%d,%f",&iAge,&fWeight);

    printf("Please input your height(cm):\n");
    scanf("%d",&iHeight);

    float fBMI = fWeight / pow((iHeight/100.0),2);
    printf("Age = %d, Weight(kg) = %.2f, Height(cm) = %d, BMI = %.2f",
           iAge,fWeight,iHeight,fBMI);

    return 0;
}
