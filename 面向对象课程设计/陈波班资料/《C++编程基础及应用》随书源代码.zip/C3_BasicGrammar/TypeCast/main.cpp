//Project - TypeCast
#include <iostream>
using namespace std;

int main(){
    char c = 'K';
    cout << "c = " << c << endl;
    cout << "ASCII code for 'K': " << (int)c << endl;
    cout << "ASCII code for 'K': " << int(c) << endl;
    cout << "ASCII code for 'K': " << static_cast<int>(c) << endl;
    return 0;
}
