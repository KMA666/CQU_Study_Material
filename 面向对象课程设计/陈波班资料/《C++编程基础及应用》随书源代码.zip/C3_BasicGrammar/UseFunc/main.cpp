//Project - UseFunc
#include <cstdio>
#include <cmath>
#include <cstdlib>

int main(){
    double x = 2, y = 8;
    printf("2^8 = %f\n", pow(x,y));              //x的y次方
    printf("round(25.51) = %f\n", round(25.51)); //四舍五入
    printf("floor(25.997) = %f\n",floor(25.997));//下取整
    printf("ceil(25.01) = %f\n", ceil(25.01));   //上取整
    printf("sqrt(5) = %f\n",sqrt(5));            //平方根

    int r0 = rand();                             //0 ~ RAND_MAX之间的随机整数
    int r1 = rand() % 100;                       //0 ~ 99之间的随机数
    double r2 = 0.1 + 0.1*rand()/RAND_MAX;       //0.1 ~ 0.2之间的随机浮点数
    printf("r0 = %d, r1 = %d, r2 = %f\n",r0,r1,r2);
    printf("RAND_MAX = %x",RAND_MAX);

    return 0;
}
