//Project - Comment
/*
The following program was written by Alex, all rights reserved.
I hope that this book can lead you into the fantastic world of programming.
Loving Alex  chenbo@cqu.edu.cn
*/

#include <iostream>

//iostream introduced cout object to this file
int main() {
    std::cout << "Hello World!\n";
    return 0;
}
