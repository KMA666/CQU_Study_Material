//Project - Modulus
#include <iostream>
using namespace std;

int main(){
    int a = 10;
    int b = a % 7;
    cout << b << " is an " << (b%2==0?"even":"odd") << " number.";
    return 0;
}
