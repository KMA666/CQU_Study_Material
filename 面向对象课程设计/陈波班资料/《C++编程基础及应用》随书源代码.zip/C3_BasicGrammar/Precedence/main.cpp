//Project - Precedence
#include <iostream>
using namespace std;

int main(){
    int n = 3 + 2 * 6 / 3;
    cout << n << endl;

    n = (3 + 2) * 6 / 3;
    cout << n << endl;
    return 0;
}
