//Project - AssignType
#include <iostream>
using namespace std;

int main(){
    bool a = 3.0;            //转换为bool类型：0为false，非0为true
    float b = -99999.2301;   //double转float，精度降低，可能超出储值范围
    int c = b;               //float转int, 小数部分丢失，可能超出储值范围
    unsigned int d = c;      //int转unsigned int，负值被错误解释
    short e = d;             //unsigned int转short，可能超出储值范围
    double f = b;            //float转double，安全

    cout.setf(ios_base::fixed, ios_base::floatfield);
    cout << "a = " << a << "\nb = " << b << "\nc = " << c
         << "\nd = " << d << "\ne = " << e << "\nf = " << f;
    return 0;
}
