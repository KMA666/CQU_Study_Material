#include <iostream>
 using namespace std;  int
        main() {
cout<< "Working codes, but in chaos." ;return 0
; }
