//Project - AmbiguousIncDec
#include <cstdio>

int main(){
    int n = 4;
    printf("%d - %d\n",n,n*n++);

    n = 5;
    printf("%d",n/2+5*(1+n++));

    return 0;
}
