//Project - CppInput
#include <iostream>
#include <math.h>
using namespace std;

int main() {
    int iAge {}, iHeight {};
    float fWeight {};

    cout << "Please input your age, weight(kg):" << endl;
    cin >> iAge >> fWeight;

    cout << "Please input your height(cm):\n";
    cin >> iHeight;

    float fBMI = fWeight / pow((iHeight/100.0),2);
    cout << "Age = " << iAge << ", Weight(kg) = " << fWeight
         << ", Height(cm) = " << iHeight << ", BMI = " << fBMI;

    return 0;
}
