//Project - BoolShort2
#include <iostream>
using namespace std;

int main(){
    int x = 0, y = 0, z = 0;
    bool b = (x++) || (++y) || (z++);

    cout << "b = " << b << endl;
    cout << "x = " << x << endl;
    cout << "y = " << y << endl;
    cout << "z = " << z << endl;
    return 0;
}
