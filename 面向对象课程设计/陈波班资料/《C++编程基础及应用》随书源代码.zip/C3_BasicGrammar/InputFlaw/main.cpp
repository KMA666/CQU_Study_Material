#include <cstdio>

int main() {
    int iNumber = 3;   //" vs ”     )  vs ）
    printf("There are %d stars surrounding three body planet.", iNumber);
    return 0;
}
