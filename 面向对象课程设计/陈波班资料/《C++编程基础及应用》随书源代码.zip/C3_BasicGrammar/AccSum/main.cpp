//Project - AccSum
#include <iostream>
using namespace std;

int accSum(int n){
    n && (n = n+accSum(n-1));
    return n;
}

int main()
{
    cout << "1+2+...+99+100 = " << accSum(100);
    return 0;
}
