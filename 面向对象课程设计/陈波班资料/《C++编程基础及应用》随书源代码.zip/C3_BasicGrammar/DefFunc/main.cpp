//Project - DefFunc
#include <iostream>
using namespace std;

//电费计算: (期末读数 - 期初读数) * 单价
float costCompute(int iStart, int iEnd)
{
    int iConsume = iEnd - iStart;
    return iConsume * 0.85f;
}

int main(){
    float fElecFee1 = costCompute(1201,1786);
    cout << "Electronic Power Cost of Mr Zhang: " << fElecFee1 << endl;

    float fElecFee2 = costCompute(1322,1423);
    cout << "Electronic Power Cost of Mr Lee: " << fElecFee2 << endl;

    return 0;
}
