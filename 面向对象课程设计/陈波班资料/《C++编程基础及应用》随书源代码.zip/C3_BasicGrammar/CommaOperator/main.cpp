//Project - CommaOperator
#include <iostream>
using namespace std;

int main() {
    int a = 3, b=7;
    a = (b++,a*2);
    cout << "a = " << a << ", b = " << b;
    return 0;
}
