//Project - ChangePrecedence
#include <iostream>
using namespace std;

int main(){
    int r = 3 + 2 && 0;
    cout << "3 + 2 && 0 = " << r << endl;

    r = (3 + 2) && 0;
    cout << "(3 + 2) && 0 = " << r << endl;

    r = 3 + (2 && 0);
    cout << "3 + (2 && 0) = " << r << endl;

    return 0;
}
