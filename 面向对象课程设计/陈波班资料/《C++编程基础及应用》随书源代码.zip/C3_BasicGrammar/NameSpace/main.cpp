//Project - NameSpace
#include <iostream>
//using namespace std;

namespace Rocket {
    int n {2};
}

int main(){
    int n {1};
    std::cout << "n = " << n << ", Rocket::n = " << Rocket::n;
    return 0;
}


