//Project - LocalTime
#include <stdio.h>
#include <time.h>

int main() {
    time_t t;
    struct tm * timeInfo;

    time(&t);
    timeInfo = localtime(&t); //从t转换出本地日期时间

    printf("%d-%d-%d %d:%d:%d",1900+timeInfo->tm_year,timeInfo->tm_mon+1,
           timeInfo->tm_mday,timeInfo->tm_hour,timeInfo->tm_min,timeInfo->tm_sec);

    return 0;
}
