//Project - IncDec
#include <iostream>
using namespace std;

int main(){
    int a = 10, b, c;
    b = a++;    //先取值，后递增，a改为11，b得递增之前的值10
    c = ++a;    //先递增，后取值，a改为12，c得递增之后的值12
    cout << "a = " << a << ", b = " << b << ", c = " << c << endl;

    float f = 10.1f, g, h;
    g = f--;    //先取值，后递减
    h = --f;    //先递减，后取值
    cout << "f = " << f << ", g = " << g << ", h = " << h << endl;

    return 0;
}
