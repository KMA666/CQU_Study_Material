//Project - CompLogic
#include <iostream>
using namespace std;

int main(){
    int a = 10;
    cout << "a>5: " << (a>5) << endl;
    cout << "a<20 and a>=10: " << (a<20 && a>=10) << endl;
    cout << "a==9: " << (a==9) << endl;
    cout << "a!=3: " << (a!=3) << endl;
    cout << "a>100 or a<20: " << (a>100 || a<20) << endl;
    cout << "not a>=10: " << (!(a>=10)) << endl;
    return 0;
}
