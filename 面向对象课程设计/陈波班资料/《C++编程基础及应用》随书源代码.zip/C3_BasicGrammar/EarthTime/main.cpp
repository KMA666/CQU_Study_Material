//Project - EarthTime
#include <cstdio>
#include <ctime>

int main() {
    time_t t;
    time(&t); //获取当前时间,从1970年1月1日零时起经过的秒数

    long long totalSeconds = (long long)t;      //总秒数转换为long long类型
    long long curSecond = totalSeconds % 60;    //当前秒数 = 总秒数对60取余
    long long totalMinutes = totalSeconds / 60; //总分钟 = 总秒数除60
    long long curMinute = totalMinutes % 60;    //当前分钟 = 总分钟对60取余
    long long totalHours = totalMinutes / 60;   //总小时 = 总分钟除60
    long long curHour = totalHours % 24;        //当前小时 = 总小时对24取余

    printf("格林尼治时间 %lld 时 %lld 分 %lld 秒,1970年1月1日零时到现在经过了 %lld 秒.",
           curHour,curMinute,curSecond,totalSeconds);

    /* printf的英文版本
    printf("%lld:%lld:%lld, %lld seconds after 1970/1/1 00:00::00",
           curHour,curMinute,curSecond,totalSeconds);
    */

    return 0;
}
