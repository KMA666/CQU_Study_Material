//Program - Constant
#include <iostream>
using namespace std;

#define PI 3.1415926
int main(){
    float r = 2;
    const float CPI = 3.1415926f;
    //CPI = 4;      //常量不能修改

    cout << "Area of circle = " << PI*r*r << endl;
    cout << "Area of circle = " << CPI*r*r << endl;
    return 0;
}
