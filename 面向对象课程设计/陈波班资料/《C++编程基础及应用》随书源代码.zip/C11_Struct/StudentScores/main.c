//Project - StudentScores
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char sName[20]; //学生姓名
    int  n;         //已修课程数量
    float* scores;  //指针作为结构成员，分数数组
} Student;

int main() {
    Student s = {"Dorothy Henry", 4, NULL};
    printf("sizeof(s) = %lld, sizeof(s.sName) = %lld, "
           "sizeof(s.n) = %lld, sizeof(s.scores) = %lld\n",
           sizeof(s),sizeof(s.sName),sizeof(s.n),sizeof(s.scores));

    s.scores = calloc(s.n,sizeof(float));

    s.scores[0] = 80;  s.scores[1] = 90; s.scores[2] = 90; s.scores[3] = 80;
    float fSum = 0;
    for (int i=0;i<s.n;i++)
        fSum += s.scores[i];
    printf("Average score of %s: %f",s.sName,fSum/s.n);

    free(s.scores);
    return 0;
}
