//Project - FlexMember
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char sName[20];  //学生姓名
    int  n;          //已修课程数量
    float scores[];  //柔性数组成员
} Student;

int main() {
    unsigned int nBytes = sizeof(Student) + 4*sizeof(float);
    Student* s = malloc(nBytes);
    printf("sizeof(*s) = %lld, sizeof(s->sName) = %lld, "
           "sizeof(s->n) = %lld, nBytes = %lld\n",
           sizeof(*s),sizeof(s->sName),sizeof(s->n), nBytes);

    printf("s = %p, s->scores = %p\n", s, s->scores);

    s->n = 4;
    s->scores[0] = 80;  s->scores[1] = 90; s->scores[2] = 90; s->scores[3] = 80;
    float fSum = 0;
    for (int i=0;i<s->n;i++)
        fSum += s->scores[i];
    printf("Average score: %f",fSum/s->n);

    free(s);
    return 0;
}
