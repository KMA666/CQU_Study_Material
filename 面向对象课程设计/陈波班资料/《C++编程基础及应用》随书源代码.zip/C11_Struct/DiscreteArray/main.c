#include <stdio.h>

typedef enum {
    male = 0, female = 1
} GenderType;

char idEmployees[1000][30];        //身份证号字符串数组
char nameEmployees[1000][256];     //姓名字符串数组
int  salaryEmployees[1000];        //月薪字符串数组
GenderType genderEmployees[1000];  //性别数组

int main() {
    printf("%p, %p, %p, %p\n", idEmployees, nameEmployees,
           salaryEmployees, genderEmployees);
    return 0;
}
