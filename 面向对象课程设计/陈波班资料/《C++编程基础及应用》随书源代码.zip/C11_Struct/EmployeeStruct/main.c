//Project - EmployeeStruct
#include <stdio.h>
#include <stdbool.h>

typedef enum {
    male = 0, female = 1
} GenderType;

struct Employee {
    char sName[10];     //姓名
    bool bRetired;      //是否已退休
    int  iSalary;       //月薪
    GenderType gender;  //性别
};  //注意末尾分号不能少

int main() {
    struct Employee e = {.sName = "Jack Ma", .iSalary = 9000,
                         .gender = male, .bRetired = false};

    printf("&e = %p, size = %lld\n", &e, sizeof(e));
    printf("e.sName = %p, size = %lld\n", e.sName, sizeof(e.sName));
    printf("&e.bRetired = %p, size = %lld\n", &e.bRetired, sizeof(e.bRetired));
    printf("&e.iSalary = %p, size = %lld\n", &e.iSalary, sizeof(e.iSalary));
    printf("&e.gender = %p, size = %lld\n", &e.gender, sizeof(e.gender));

    return 0;
}
