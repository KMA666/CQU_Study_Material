//Project - EmployeeArray
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef enum {
    male = 0, female = 1
} GenderType;

typedef struct {
    char sName[20];     //姓名
    int  iSalary;       //月薪
    GenderType gender;  //性别
} Employee;

int main() {
    Employee es0[3] = { //3个数组元素初始化，提供3个复合字面量
        {"Jack Ma", 9000, male},
        {"Dorothy Henry", 5000, female},
        {"Frank Bush", 6000, male}
    };

    Employee* es1 = (Employee*)calloc(3,sizeof(Employee));
    for (int i=0;i<3;i++)
        es1[i] = es0[i];

    es0[1].iSalary += 200;     //es0[1]指Dorothy
    //es0.iSalary[1] += 200;   //错误语法

    Employee* p = es1;
    p++;               //p向右滑动一个对象，指向es1[1]，即Dorothy
    p->iSalary += 200; //修改的是es1[1]，即Dorothy的Salary

    printf("Name:  %s,  Salary: %d\n", es0[1].sName,es0[1].iSalary);
    printf("Name:  %s,  Salary: %d\n", es1[1].sName,es1[1].iSalary);

    free(es1);         //释放calloc取得的动态内存空间
    return 0;
}
