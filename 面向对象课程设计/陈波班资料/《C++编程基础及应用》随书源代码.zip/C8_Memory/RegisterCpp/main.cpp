//Project - RegisterCpp
#include <iostream>
using namespace std;

int main()
{
    register int i = 0;
    cout << &i << endl;
    return 0;
}
