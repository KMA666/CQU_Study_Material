//Project - NewDelete1
#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    int i = 3;
    int* p = new int;
    *p = 5;

    printf("i = %d, &i = %p\n", i, &i);
    printf("p = %p, &p = %p, *p = %d\n", p, &p, *p);

    delete p;
    printf("p = %p", p);

    return 0;
}
