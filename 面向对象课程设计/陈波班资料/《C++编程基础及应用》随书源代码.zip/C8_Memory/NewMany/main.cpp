//Project - NewMany
#include <iostream>
using namespace std;

int main() {
    int n = 100;
    int* a = new int[n];
    int iSum {0};
    for (int i=0;i<100;i++){
        a[i] = i+1;
        iSum += a[i];
    }

    delete []a;  //同delete[] a;
    a = nullptr;

    cout << "sum = " << iSum << endl;
    return 0;
}
