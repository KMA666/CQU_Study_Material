//Project - New0
#include <iostream>
using namespace std;

int main(){
    int* a = new int();
    float* b = new float(0);
    double* c = new double(3.3);

    cout << *a << ", " << *b << ", " << *c << endl;

    delete a;
    delete b;
    delete c;
    return 0;
}
