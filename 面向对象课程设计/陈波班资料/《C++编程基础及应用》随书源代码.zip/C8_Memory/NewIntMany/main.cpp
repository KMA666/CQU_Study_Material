//Project - NewIntMany
#include <iostream>
using namespace std;

int main() {
    int* p[100] {nullptr};
    for (auto i=0;i<100;i++){
        p[i] = new int;
    }

    for (auto i=0;i<100;i++){
        printf("%p\n",p[i]);
        delete p[i];
    }
    return 0;
}
