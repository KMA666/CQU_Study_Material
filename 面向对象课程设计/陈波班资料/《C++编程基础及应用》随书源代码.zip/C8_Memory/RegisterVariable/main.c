//Project - RegisterVariable
#include <stdio.h>

int main()
{
    register int i = 0;
    printf("&i = %p, i = %d", &i, i);
    return 0;
}
