//Project - IsPrime
#include <iostream>
using namespace std;

bool isPrime(int);         //函数的声明

int main(){
    cout << "isPrime(-2):\t" << (isPrime(-2)?"Yes":"No") << endl;
    cout << "isPrime(3):\t" << (isPrime(3)?"Yes":"No") << endl;
    cout << "isPrime(4):\t" << (isPrime(4)?"Yes":"No") << endl;
    cout << "isPrime(117):\t" << (isPrime(117)?"Yes":"No") << endl;
    cout << "isPrime(131):\t" << (isPrime(131)?"Yes":"No") << endl;
    return 0;
}

bool isPrime(int n) {     //函数的定义
    if (n<=1)
        return false;
    for (int i=2;i<n;i++)
        if (n % i == 0)
            return false;

    return true;
}


