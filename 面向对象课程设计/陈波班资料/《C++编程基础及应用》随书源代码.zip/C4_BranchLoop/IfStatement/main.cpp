//Project - IfStatement
#include <iostream>
using namespace std;

int main(){
    int iAge = 0;
    cout << "Hey, how old are you ? boy.\n";
    cin >> iAge;

    if (iAge>=18)   //括号()必须
        cout << "You are legally an adult.\n";

    if (iAge>=22){
        cout << "Congratulations, son!\n";
        cout << "You are of legal age for marriage.\n";
    }

    return 0;
}
