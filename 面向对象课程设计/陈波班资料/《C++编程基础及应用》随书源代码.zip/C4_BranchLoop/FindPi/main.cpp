//Project - FindPi
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    const int N = 1000000;    //投点总数
    int nHits = 0;          //圆内投点数

    for (int i=0;i<N;i++){
        double x = 2.0*rand()/RAND_MAX - 1.0; //随机数取投点x坐标
        double y = 2.0*rand()/RAND_MAX - 1.0; //随机数取投点x坐标
        if (x*x + y*y <= 1.0)  //投点位于内切圆内
            nHits += 1;        //圆内投点数+1
    }

    double pi = 4.0*nHits/N;   //通过计算圆面积估算圆周率
    cout << "pi = " << pi;
    return 0;
}
