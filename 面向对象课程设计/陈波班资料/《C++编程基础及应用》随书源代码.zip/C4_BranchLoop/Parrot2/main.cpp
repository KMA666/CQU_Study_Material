//Project - Parrot2
#include <iostream>
#include <string>

int main(){
    using namespace std;

    cout << "I am a parrot, say something to me." << endl;
    string s = "";
    while (true){
        getline(cin,s);
        if (s=="q")
            break;
        cout << s << endl;
    }

    cout << "Bye, see you later." << endl;
    return 0;
}
