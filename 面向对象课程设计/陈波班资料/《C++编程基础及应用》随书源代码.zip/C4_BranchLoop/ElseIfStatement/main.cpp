//Project - ElseIfStatement
#include <cstdio>

float feeCompute(float fAmount, int iPersonCount){
    float fAverage = fAmount / iPersonCount;     //人均用电量
    float fFamilyBaseAmt = iPersonCount * 50.0F; //家庭基准用电量
    float fFee = 0;                              //家庭电费

    if (fAverage <=50.0F)
        fFee = fAmount * 0.7F;
    else if (fAverage <= 100.0F)
        fFee = (fAmount - fFamilyBaseAmt) * 1.0F + fFamilyBaseAmt * 0.7F;
    else if (fAverage <= 200.0F) {
        printf("Inside function feeCompute: 100 < Average <= 200.\n");
        fFee = (fAmount - fFamilyBaseAmt) * 1.5F + fFamilyBaseAmt * 0.7F;
    }
    else
        fFee = (fAmount - fFamilyBaseAmt) * 2.0F + fFamilyBaseAmt * 0.7F;

    return fFee;
}

int main(){
    float fFee =feeCompute(768.1F, 4);
    printf("Energy used: %.2f kWh, Person count: %d, Electricity bill: %.2f\n",
           768.1F,4,fFee);
    return 0;
}
