//Project - DoubleFor
#include <iostream>
using namespace std;

int main()
{
    for (int i=0;i<10;i++){   //i循环：第0行至第9行
        for (int j=0;j<10;j++){ //j循环：第0列至第9列，但第i行最多输出10-i列
            if (j>=(10-i))
                break;
            cout << "*";
        }
        cout << endl;
    }

    return 0;
}
