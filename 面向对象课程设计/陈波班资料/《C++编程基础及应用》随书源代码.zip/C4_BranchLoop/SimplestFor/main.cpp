//Project - SimplestFor
#include <iostream>
using namespace std;

int main() {
    int iSum = 0;

    for (int i=0;i<3;i++){
        cout << "loop i = "  << i << endl;
        iSum += i;
    }

    cout << "sum = " << iSum;
    return 0;
}
