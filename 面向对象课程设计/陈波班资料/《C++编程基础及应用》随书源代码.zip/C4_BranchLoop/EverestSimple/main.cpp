//Project - EverestSimple
#include <iostream>
#include <cmath>    //引入log2()函数
using namespace std;

int main(){
    double t = log2(8844.43/0.0001);
    cout << t;

    cout << endl << 0.0001 * pow(2,27);
    return 0;
}
