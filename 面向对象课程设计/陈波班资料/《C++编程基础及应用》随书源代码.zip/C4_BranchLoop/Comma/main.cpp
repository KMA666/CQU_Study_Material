//Project - Comma
#include <cstdio>

int main() {
   int a = 0, b = 0;

   a = b++, 3;

   printf("a = %d, b = %d",a,b);
   return 0;
}
