//Project - Sum100
#include <iostream>
using namespace std;
int main(){
    int iSum = 0, i = 0;
    for (i=1;i<100;i++)
        iSum += i;

    cout << "sum = " << iSum << ", i = " << i;
    return 0;
}
