//Project - Everest
#include <iostream>
using namespace std;

int main() {
    int iCounter = 0;              //对折次数
    float fThickness = 0.0001F;    //纸厚，单位米

    while (true){
        if (fThickness > 8844.43F) //超过珠峰高度就停止循环
            break;
        else{
            fThickness *= 2;       //对折一次厚度翻倍
            iCounter++;            //对折次数加1
        }
    }

    cout << "Thickness = " << fThickness << " after "
         << iCounter << " folds, exceeding Everest.";
    return 0;
}
