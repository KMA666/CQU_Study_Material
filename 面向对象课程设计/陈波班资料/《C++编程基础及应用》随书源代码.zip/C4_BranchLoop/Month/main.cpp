//Month
#include <iostream>
using namespace std;
int main() {
    int iMonth = 1;
    cout << "Please input month number(1~12):";
    cin >> iMonth;

    switch (iMonth){
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
        cout << "There are 31 days in " << iMonth << "th month.\n";
        break;
    case 2:
        cout << "There are 28 or 29 days in " << iMonth << "th month.\n";
        //break;  //break缺失
    case 4:
    case 6:
    case 9:
    case 11:
        cout << "There are 30 days in " << iMonth << "th month.\n";
        break;
    default:
        cout << "Wrong month number.\n";
    }

    return 0;
}
