//Project - Parrot1
#include <iostream>
#include <string>

int main(){
    using namespace std;

    cout << "I am a parrot, say something to me." << endl;
    string s = "";
    while (s!="q"){
        getline(cin,s);
        cout << s << endl;
    }

    cout << "Bye, see you later." << endl;
    return 0;
}
