#include <QCoreApplication>
#include <QTimer>
#include "sensor.h"
#include "alarm.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Sensor sensor;
    Alarm alarm;

    QObject::connect(&sensor, &Sensor::temperatureChanged,
                     &alarm, &Alarm::onTemperatureChanged);

    QTimer timer;

    QObject::connect(&timer, &QTimer::timeout, [&](){
        static double t = 20;
        t += 10;
        sensor.setTemperature(t);
    });

    timer.start(1000);   // 每 1 秒触发一次

    return a.exec();
}
