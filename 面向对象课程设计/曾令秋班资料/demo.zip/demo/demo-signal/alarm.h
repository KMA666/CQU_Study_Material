#ifndef ALARM_H
#define ALARM_H

#include <QObject>
#include <QDebug>

class Alarm : public QObject
{
    Q_OBJECT

public slots:
    void onTemperatureChanged(double t);
};

#endif // ALARM_H
