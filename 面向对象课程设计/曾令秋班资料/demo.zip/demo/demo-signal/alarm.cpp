#include "alarm.h"



void Alarm::onTemperatureChanged(double t)
{
    if (t > 50)
        qDebug() << "Temperature Alarm:" << t;
    else
        qDebug() << "Temperature OK:" << t;
}
