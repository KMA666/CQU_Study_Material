#ifndef SENSOR_H
#define SENSOR_H


#include <QObject>

class Sensor : public QObject
{
    Q_OBJECT

public:
    explicit Sensor(QObject *parent = nullptr);

    void setTemperature(double t);

signals:
    void temperatureChanged(double newTemp);

private:
    double m_temp;
};

#endif // SENSOR_H
