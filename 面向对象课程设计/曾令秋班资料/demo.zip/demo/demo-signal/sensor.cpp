#include "sensor.h"

Sensor::Sensor(QObject *parent)
    : QObject(parent), m_temp(0)
{
}

void Sensor::setTemperature(double t)
{
    if (m_temp == t) return;

    m_temp = t;
    emit temperatureChanged(m_temp);
}
