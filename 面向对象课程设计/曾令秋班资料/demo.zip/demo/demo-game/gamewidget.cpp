#include "gamewidget.h"
#include <QPainter>
#include <QKeyEvent>

GameWidget::GameWidget(QWidget *parent)
    : QWidget(parent)
{
    // 设置布局和样式
    setFixedSize(800, 600);
    setFocusPolicy(Qt::StrongFocus);
    setAttribute(Qt::WA_TranslucentBackground);
    setStyleSheet("background: transparent;");

    // 加载贴图
    spritesheet[State::Idle] = QPixmap(":/image/idle/Unarmed_Idle_full.png");
    spritesheet[State::Walk] = QPixmap(":/image/walk/Unarmed_Walk_full.png");
    spritesheet[State::Run]  = QPixmap(":/image/run/Unarmed_Run_full.png");

    // 定时器
    connect(&timer, &QTimer::timeout, this, &GameWidget::onTick);
    timer.start(1000 / 60);   // 60 FPS
}

void GameWidget::keyPressEvent(QKeyEvent *e)
{
    if (e->key() == Qt::Key_Escape)
        emit exitToMenu();

    if (e->isAutoRepeat()) return;

    Dir newDir = dir;

    if (e->key() == Qt::Key_W || e->key() == Qt::Key_Up)    newDir = Up;
    if (e->key() == Qt::Key_S || e->key() == Qt::Key_Down)  newDir = Down;
    if (e->key() == Qt::Key_A || e->key() == Qt::Key_Left)  newDir = Left;
    if (e->key() == Qt::Key_D || e->key() == Qt::Key_Right) newDir = Right;

    dir = newDir;

    // 双击跑动
    if (tapTimer.isValid() && tapTimer.elapsed() < 300)
        state = Run;
    else {
        state = Walk;
        tapTimer.restart();
    }
}

void GameWidget::keyReleaseEvent(QKeyEvent *e)
{
    if (e->isAutoRepeat()) return;
    state = Idle;
}

int GameWidget::speed() const
{
    if (state == Run)  return 4;
    if (state == Walk) return 2;
    return 0;
}

void GameWidget::onTick()
{
    int v = speed();

    if (dir == Up)    y -= v;
    if (dir == Down)  y += v;
    if (dir == Left)  x -= v;
    if (dir == Right) x += v;

    if (state != State::Idle)
        frame = (frame + 1) % maxFrame[state];

    update();
}

QPixmap GameWidget::getSprite()
{
    QPixmap sheet = spritesheet[state];

    int w0 = 20, h0 = 20;
    int w = 22, h = 28;
    int deltaW = 64, deltaH = 64;

    int dirIndex = static_cast<int>(dir);
    int frameIndex = frame % maxFrame[state]; // maxFrame 每个动作不同

    // 获取对应切图位置
    int sx = w0 + frameIndex * deltaW;
    int sy = h0 + dirIndex * deltaH;

    return sheet.copy(sx, sy, w, h);
}

void GameWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.drawPixmap(x, y, getSprite());
}
