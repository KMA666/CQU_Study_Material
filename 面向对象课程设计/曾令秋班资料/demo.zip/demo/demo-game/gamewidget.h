#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QTimer>
#include <QElapsedTimer>
#include <QPixmap>
#include <QMap>

class GameWidget : public QWidget
{
    Q_OBJECT
public:
    explicit GameWidget(QWidget *parent = nullptr);

protected:
    // 绘图事件
    void paintEvent(QPaintEvent *) override;

    // 按下 key 事件
    void keyPressEvent(QKeyEvent *) override;

    // 释放 key 事件
    void keyReleaseEvent(QKeyEvent *) override;

    // 定义信号
signals:
    void exitToMenu();

    // 定义槽函数
private slots:
    void onTick();

private:
    // 玩家方向
    enum Dir { Down, Left, Right, Up };

    // 玩家状态 (静止, 步行, 跑)
    enum State { Idle, Walk, Run };

    // 初始方向, 状态
    Dir dir = Down;
    State state = Idle;

    // 初始位置
    int x = 200;
    int y = 200;

    // 玩家状态动作所在帧下标
    int frame = 0;

    // 玩家状态动作帧数
    QMap<State, int> maxFrame = {
        { State::Idle, 1 },
        { State::Walk, 6 },
        { State::Run, 8 }
    };

    // 定时器 定时触发更新UI
    QTimer timer;

    // 用来记录上一次按键的时间
    QElapsedTimer tapTimer;

    // 人物切图
    QMap<State, QPixmap> spritesheet;

    // 获取切图
    QPixmap getSprite();

    // 获取速度
    int speed() const;
};

#endif
