#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 游戏内容显示 gamePage 上
    game = new GameWidget(ui->gamePage);
    game->setGeometry(ui->gamePage->rect());
    game->show();

    // exit 按键和返回菜单页槽函数绑定
    connect(game, &GameWidget::exitToMenu, this, [=](){
        ui->stackedWidget->setCurrentWidget(ui->menuPage);
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

// begin 按钮 进入游戏界面
void MainWindow::on_beginButton_released()
{
    ui->stackedWidget->setCurrentWidget(ui->gamePage);
    game->setFocus();
}

// exit 按钮 退出程序
void MainWindow::on_exitButton_released()
{
    QApplication::quit();
}
